$file = 'C:\Users\karan\AppData\Roaming\Adobe\CEP\extensions\QwintSubtitileCEP\js\panel.js'
$content = Get-Content $file -Raw -Encoding UTF8

# Find the function by matching a unique string inside it
$oldBlock = '  // Normalize ALL timestamp variants (MM:SS,mmm AND HH:MM:SS,mmm) to HH:MM:SS,mmm
  function normalizeSrtTimestamps(text) {
    // Matches: optional HH: + MM:SS,mmm --> optional HH: + MM:SS,mmm
    return text.replace(
      /((?:\d{1,2}:)?\d{1,2}:\d{2},\d{3})\s*-->'

# Use line-based replacement instead
$lines = $content -split "`n"
$startLine = -1
$endLine = -1
for ($i = 0; $i -lt $lines.Count; $i++) {
    if ($lines[$i] -match 'Normalize ALL timestamp variants') {
        $startLine = $i
    }
    if ($startLine -ge 0 -and $i -gt $startLine -and $lines[$i] -match '^\s*\}\s*$') {
        $endLine = $i
        break
    }
}

Write-Host "Found function at lines $startLine to $endLine"

if ($startLine -ge 0 -and $endLine -gt $startLine) {
    $newFunc = @(
        '  // Normalize ALL broken AI timestamp formats -> standard HH:MM:SS,mmm --> HH:MM:SS,mmm',
        '  function normalizeSrtTimestamps(text) {',
        '    var lines = text.split(chr(10));',
        '    var out = [];',
        '    for (var i = 0; i < lines.length; i++) {',
        '      var line = lines[i];',
        '      line = line.replace(/(\d{1,2}):(\d{2}):(\d{3})(?=\s|,|$|-)/g, function(m, a, b, c) {',
        '        return parseInt(c) > 59 ? a + chr(58) + b + chr(44) + c : m;',
        '      });',
        '      line = line.replace(/^(\d{1,2}:\d{2},\d{3}),(\d{1,2}:\d{2},\d{3})\s*$/, chr(36) + chr(49) + " --> " + chr(36) + chr(50));',
        '      line = line.replace(/((?:\d{1,2}:)?(?:\d{1,2}:)?\d{1,2},\d{3})\s*-->\s*((?:\d{1,2}:)?(?:\d{1,2}:)?\d{1,2},\d{3})/g,',
        '        function(m, s, e) { return formatSrtTime(parseSrtTime(s)) + " --> " + formatSrtTime(parseSrtTime(e)); }',
        '      );',
        '      out.push(line);',
        '    }',
        '    return out.join(chr(10));',
        '  }'
    )
    Write-Host "Function found and would be replaced - but using direct approach instead"
}

Write-Host "Script complete - use direct file edit approach"
