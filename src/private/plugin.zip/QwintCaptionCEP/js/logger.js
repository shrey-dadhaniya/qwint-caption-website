/**
 * Logger module for Qwint Caption CEP Extension.
 * Logs are stored in the 'logs' folder of the extension directory.
 * Format: SR NO, TIMESTAMP, ACTIVITY, DURATION, STATUS
 */

(function () {
    var fs, path, logsDir, logFile;

    try {
        // Node.js requirements
        fs = require('fs');
        path = require('path');

        var baseDir = "";
        try {
            var cs = new CSInterface();
            baseDir = cs.getSystemPath(SystemPath.EXTENSION);
            // Clean up the path for Windows
            if (baseDir.charAt(0) === "/" && window.navigator.platform.indexOf("Win") !== -1) {
                baseDir = baseDir.substring(1);
            }
        } catch (e) {
            console.error("[LOGGER]: Failed to get SystemPath.EXTENSION", e);
            // Fallback to location-based path
            baseDir = window.location.pathname.substring(0, window.location.pathname.lastIndexOf('/'));
            if (baseDir.startsWith("file:///")) baseDir = baseDir.substring(8);
            if (baseDir.startsWith("/") && window.navigator.platform.indexOf("Win") !== -1) baseDir = baseDir.substring(1);
        }

        logsDir = path.join(baseDir, 'logs');
        logFile = path.join(logsDir, 'activity_logs.csv');

        console.log("[LOGGER]: Initialized. Log file: " + logFile);
    } catch (e) {
        console.error("[LOGGER]: Initialization error", e);
    }

    function initLogs() {
        if (!fs) return;
        try {
            if (!fs.existsSync(logsDir)) {
                fs.mkdirSync(logsDir, { recursive: true });
                console.log("[LOGGER]: Created logs directory: " + logsDir);
            }

            var header = "SR NO,TIMESTAMP,ACTIVITY,DURATION,STATUS\n";

            if (!fs.existsSync(logFile)) {
                fs.writeFileSync(logFile, header, 'utf8');
                console.log("[LOGGER]: Created log file with headers.");
            } else {
                // If it exists but has the OLD header, migrate it
                var content = fs.readFileSync(logFile, 'utf8');
                if (content.indexOf("SR NO,TIMESTAMP,ACTIVITY,STATUS") !== -1) {
                    console.log("[LOGGER]: Migrating old log file to include DURATION column...");
                    var lines = content.trim().split('\n');
                    var newLines = [header.trim()];
                    for (var i = 1; i < lines.length; i++) {
                        // Split by comma but respect quoted values
                        // Simple split here as we controlled the activity entry previously with cleanActivity
                        var parts = lines[i].split(/,(?=(?:(?:[^"]*"){2})*[^"]*$)/);
                        if (parts.length === 4) {
                            // Insert empty duration
                            newLines.push(parts[0] + "," + parts[1] + "," + parts[2] + ",-," + parts[3]);
                        } else {
                            newLines.push(lines[i]);
                        }
                    }
                    fs.writeFileSync(logFile, newLines.join('\n') + '\n', 'utf8');
                }
            }
        } catch (err) {
            console.error("[LOGGER]: Failed to init or migrate logs.", err);
        }
    }

    function logActivity(activity, success, duration) {
        console.log("[LOGGER]: Attempting to log: " + activity + (duration ? " (" + duration + "s)" : ""));

        if (!fs) {
            console.warn("[LOGGER]: FS not available. Cannot write to file.");
            return;
        }

        try {
            initLogs();

            var srNo = 1;
            try {
                var fileContent = fs.readFileSync(logFile, 'utf8');
                var lines = fileContent.trim().split('\n');
                srNo = lines.length;
            } catch (readErr) {
                console.error("[LOGGER]: Could not read log file for SR NO", readErr);
            }

            var timestamp = new Date().toLocaleString();
            var durStr = duration ? duration + "s" : "-";
            var status = success ? "SUCCESS" : "FAILURE";
            var cleanActivity = (activity || "").toString().replace(/,/g, ';').replace(/\n/g, ' ');

            var logEntry = srNo + ',"' + timestamp + '","' + cleanActivity + '","' + durStr + '","' + status + '"\n';

            fs.appendFileSync(logFile, logEntry, 'utf8');
            console.log("[LOGGER]: Log written successfully.");
        } catch (error) {
            console.error("[LOGGER ERROR]: Failed to append to log file", error);
        }
    }

    // Export to global window object
    if (typeof window !== 'undefined') {
        window.logActivity = logActivity;
        window.initLogs = initLogs;
    }

    // Export as module if possible
    if (typeof module !== 'undefined' && module.exports) {
        module.exports = { logActivity: logActivity, initLogs: initLogs };
    }

    // Auto-init on load
    try {
        initLogs();
    } catch (e) { }

})();
