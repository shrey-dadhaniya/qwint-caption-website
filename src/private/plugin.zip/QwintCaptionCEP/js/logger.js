/**
 * logger.js - Production-Grade RUM & Telemetry System
 * Flows: Events -> Central Logger -> IndexedDB -> Batch Sender -> OpenObserve
 */

(function (window) {
    "use strict";

    // --- PART 1: SESSION TRACKING ---
    if (!window.qwintSessionId) {
        try {
            window.qwintSessionId = crypto.randomUUID();
        } catch (e) {
            window.qwintSessionId = 'qwint-' + Math.random().toString(36).substring(2, 15) + '-' + Date.now();
        }
    }

    // --- PART 3: CENTRAL LOGGER ---
    /**
     * Unified logging function to be used throughout the plugin
     */
    async function qwintLog(level, event, data) {
        const log = {
            plugin: "qwint-caption",
            version: "1.0.0",
            session_id: window.qwintSessionId,
            level: level.toLowerCase(),
            event: event,
            data: data || {},
            timestamp: new Date().toISOString()
        };

        // Local development logging
        console.log(`[QwintLog][${log.level.toUpperCase()}] ${event}`, data || "");

        // Save to IndexedDB (Implemented in db.js)
        if (window.QwintDB && typeof window.QwintDB.saveLogToIndexedDB === 'function') {
            try {
                await window.QwintDB.saveLogToIndexedDB(log);
            } catch (err) {
                console.error("Critical: Failed to save log to IndexedDB", err);
            }
        }
    }

    // --- PART 9: API MONITORING ---
    /**
     * Tracks fetch requests for success/failure and latency
     */
    async function trackedFetch(url, options) {
        const start = performance.now();
        try {
            const response = await fetch(url, options);
            qwintLog("info", "api_success", {
                url: url,
                status: response.status,
                latency_ms: (performance.now() - start).toFixed(2)
            });
            return response;
        } catch (error) {
            qwintLog("error", "api_failed", {
                url: url,
                message: error.message
            });
            throw error;
        }
    }

    // --- PART 10: ERROR TRACKING ---
    window.onerror = function (message, source, lineno, colno, error) {
        qwintLog("error", "runtime_error", {
            message: message,
            source: source,
            line: lineno,
            col: colno,
            stack: error ? error.stack : ""
        });
    };

    const originalError = console.error;
    console.error = function (...args) {
        const message = args.map(arg => {
            try {
                return typeof arg === 'object' ? JSON.stringify(arg) : String(arg);
            } catch (e) {
                return String(arg);
            }
        }).join(" ");

        qwintLog("error", "console_error", { message: message });
        originalError.apply(console, args);
    };

    // --- PART 11: ENVIRONMENT INFO ---
    window.addEventListener('load', function () {
        qwintLog("info", "plugin_loaded", {
            userAgent: navigator.userAgent,
            platform: navigator.platform,
            language: navigator.language,
            screen: `${window.screen.width}x${window.screen.height}`
        });
    });

    // --- PART 12: MEMORY MONITORING ---
    setInterval(() => {
        if (window.performance && window.performance.memory) {
            qwintLog("info", "memory_usage", {
                usedHeap_MB: (window.performance.memory.usedJSHeapSize / 1024 / 1024).toFixed(2),
                totalHeap_MB: (window.performance.memory.totalJSHeapSize / 1024 / 1024).toFixed(2),
                heapLimit_MB: (window.performance.memory.jsHeapSizeLimit / 1024 / 1024).toFixed(2)
            });
        }
    }, 60000); // Every 60 seconds

    // Exports
    window.qwintLog = qwintLog;
    window.trackedFetch = trackedFetch;
    window.QwintLogger = {
        log: (level, event, data) => qwintLog(level.toLowerCase(), event, data)
    };

    // Compatibility alias
    window.qlog = qwintLog;

})(window);
