/**
 * sync.js - Production-Grade Background Sync Engine
 * Batches telemetry logs and sends them to OpenObserve every 30 seconds.
 */

(function (window) {
    "use strict";

    const SYNC_INTERVAL_MS = 30000; // 30 seconds
    const CLEANUP_INTERVAL_MS = 3600000; // 1 hour (for checking old logs)

    // --- OPENOBSERVE CONFIG (Dynamic) ---
    // These defaults will be used if not found in localStorage or config.json
    let OO_ORG = "3AQGD790BklrokgMk3Mh8EJagCo";
    let OO_STREAM = "default";
    let OO_TOKEN = "c2hyZXlAcXdpbnRzb2Z0LmNvbTpOM0poZEJGblQ0Y3JKbUxC"; // Based on provided shrey@qwintsoft.com credentials
    let OO_BASE_URL = "https://logs.1.shreylink.in";

    /**
     * Loads configuration from config.json file (similar to panel.js)
     */
    function loadConfig() {
        try {
            if (!window.cep || !window.cep.fs) return;

            // Try to get extension path
            let extPath = "";
            if (window.CSInterface) {
                const cs = new CSInterface();
                extPath = cs.getSystemPath(SystemPath.EXTENSION);
            }

            if (!extPath) return;

            const configPath = extPath + "/config.json";
            const result = window.cep.fs.readFile(configPath);

            if (result.err === 0) {
                const config = JSON.parse(result.data);

                if (config.ooOrg) {
                    localStorage.setItem("qwint.ooOrg", config.ooOrg);
                }
                if (config.ooStream) {
                    localStorage.setItem("qwint.ooStream", config.ooStream);
                }
                if (config.ooToken) {
                    localStorage.setItem("qwint.ooToken", config.ooToken);
                }
                if (config.ooBaseUrl) {
                    localStorage.setItem("qwint.ooBaseUrl", config.ooBaseUrl);
                }

                console.log("[SyncEngine]: Configuration loaded and persisted from config.json.");

                // Note: File deletion is handled in panel.js to avoid race conditions
                // but we still update local variables for immediate use
                updateCredentialsFromStorage();
            } else {
                // If file doesn't exist, just load from localStorage
                updateCredentialsFromStorage();
            }
        } catch (e) {
            console.warn("[SyncEngine]: Failed to load config.json", e);
            updateCredentialsFromStorage();
        }
    }

    /**
     * Updates local variables from localStorage
     */
    function updateCredentialsFromStorage() {
        OO_ORG = localStorage.getItem("qwint.ooOrg") || OO_ORG;
        OO_STREAM = localStorage.getItem("qwint.ooStream") || OO_STREAM;
        OO_TOKEN = localStorage.getItem("qwint.ooToken") || OO_TOKEN;
        OO_BASE_URL = localStorage.getItem("qwint.ooBaseUrl") || OO_BASE_URL;
    }

    /**
     * Gets the current OpenObserve endpoint
     */
    function getOOEndpoint() {
        updateCredentialsFromStorage();
        return `${OO_BASE_URL}/api/${OO_ORG}/${OO_STREAM}/_json`;
    }

    /**
     * Gets the current OpenObserve token
     */
    function getOOToken() {
        updateCredentialsFromStorage();
        return OO_TOKEN;
    }


    let syncTimer = null;
    let cleanupTimer = null;
    let isSyncing = false;

    /**
     * Starts the synchronization engine
     */
    function startLogSync() {
        if (syncTimer) return;

        console.log("[SyncEngine]: Initializing Background Sync (30s interval)");

        // Immediate sync after a short delay for startup stability
        setTimeout(performSync, 5000);

        syncTimer = setInterval(performSync, SYNC_INTERVAL_MS);
        cleanupTimer = setInterval(performCleanup, CLEANUP_INTERVAL_MS);
    }

    /**
     * Main sync logic: 1. Get logs -> 2. Send -> 3. Mark
     */
    async function performSync() {
        if (isSyncing || !window.QwintDB) return;
        if (!navigator.onLine) return; // Silent skip if offline

        isSyncing = true;

        try {
            // 1. Fetch pending logs from IndexedDB
            const entries = await window.QwintDB.getPendingLogs();

            if (!entries || entries.length === 0) {
                isSyncing = false;
                return;
            }

            // 2. Map to the final log format for OpenObserve (array of objects)
            const logBatch = entries.map(e => e.log);

            // 3. Send via POST to OpenObserve
            const success = await sendToOpenObserve(logBatch);

            if (success) {
                // 4. Mark as sent in DB
                await window.QwintDB.markLogsSent(entries);
                console.log(`[SyncEngine]: Successfully synced ${entries.length} logs to OpenObserve.`);
            }
        } catch (error) {
            console.error("[SyncEngine]: Sync process failed", error);
        } finally {
            isSyncing = false;
        }
    }

    /**
     * Network request to OpenObserve
     */
    async function sendToOpenObserve(logs) {
        const endpoint = getOOEndpoint();
        const token = getOOToken();

        try {
            const response = await fetch(endpoint, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "Authorization": `Basic ${token}`
                },
                body: JSON.stringify(logs)
            });

            if (response.ok) {
                return true;
            } else {
                console.warn(`[SyncEngine]: OpenObserve returned ${response.status}: ${response.statusText}`);
                return false;
            }
        } catch (err) {
            console.error("[SyncEngine]: Network error sending logs", err);
            return false;
        }
    }

    /**
     * Cleanup old logs to keep IndexedDB small
     */
    async function performCleanup() {
        if (!window.QwintDB) return;
        try {
            await window.QwintDB.cleanupOldLogs(7); // Keep 7 days
            console.log("[SyncEngine]: Old logs cleanup completed.");
        } catch (err) {
            console.error("[SyncEngine]: Cleanup failed", err);
        }
    }

    /**
     * Stops the engine
     */
    function stopLogSync() {
        if (syncTimer) clearInterval(syncTimer);
        if (cleanupTimer) clearInterval(cleanupTimer);
        syncTimer = null;
        cleanupTimer = null;
        console.log("[SyncEngine]: Log sync stopped.");
    }

    // Exports
    window.QwintSync = {
        startLogSync: startLogSync,
        stopLogSync: stopLogSync,
        performSync: performSync // Trigger manual sync if needed
    };

    // Auto-start
    loadConfig();
    startLogSync();

})(window);
