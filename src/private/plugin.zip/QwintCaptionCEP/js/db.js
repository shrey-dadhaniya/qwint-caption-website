/**
 * db.js - Production-Grade IndexedDB for Qwint Telemetry
 * Database: qwint_telemetry
 * Store: logs
 */

(function (window) {
    "use strict";

    const DB_NAME = "qwint_telemetry";
    const DB_VERSION = 1;
    const STORE_NAME = "logs";

    let dbInstance = null;

    /**
     * Initializes the IndexedDB for telemetry
     */
    function initLogDB() {
        if (dbInstance) return Promise.resolve(dbInstance);

        return new Promise((resolve, reject) => {
            const request = indexedDB.open(DB_NAME, DB_VERSION);

            request.onupgradeneeded = (event) => {
                const db = event.target.result;
                if (!db.objectStoreNames.contains(STORE_NAME)) {
                    const store = db.createObjectStore(STORE_NAME, {
                        keyPath: "id",
                        autoIncrement: true
                    });
                    store.createIndex("sent_status", "sent_status", { unique: false });
                    store.createIndex("timestamp", "timestamp", { unique: false });
                }
            };

            request.onsuccess = (event) => {
                dbInstance = event.target.result;
                resolve(dbInstance);
            };

            request.onerror = (event) => {
                console.error("QwintDB Init Error:", event.target.error);
                reject(event.target.error);
            };
        });
    }

    /**
     * Saves a log object into IndexedDB
     */
    async function saveLogToIndexedDB(log) {
        const db = await initLogDB();
        return new Promise((resolve, reject) => {
            const transaction = db.transaction([STORE_NAME], "readwrite");
            const store = transaction.objectStore(STORE_NAME);

            const entry = {
                log: log,
                sent_status: 0, // 0 = Pending
                timestamp: Date.now()
            };

            const request = store.add(entry);
            request.onsuccess = () => resolve();
            request.onerror = (event) => reject(event.target.error);
        });
    }

    /**
     * Retrieves all logs that have not been sent yet
     */
    async function getPendingLogs() {
        const db = await initLogDB();
        return new Promise((resolve, reject) => {
            const transaction = db.transaction([STORE_NAME], "readonly");
            const store = transaction.objectStore(STORE_NAME);
            const index = store.index("sent_status");

            // Filter for sent_status = 0 (Pending)
            const request = index.getAll(IDBKeyRange.only(0));

            request.onsuccess = (event) => {
                resolve(event.target.result || []);
            };

            request.onerror = (event) => {
                reject(event.target.error);
            };
        });
    }

    /**
     * Marks a set of logs as successfully sent
     */
    async function markLogsSent(logEntries) {
        if (!logEntries || logEntries.length === 0) return;
        const db = await initLogDB();

        return new Promise((resolve, reject) => {
            const transaction = db.transaction([STORE_NAME], "readwrite");
            const store = transaction.objectStore(STORE_NAME);

            logEntries.forEach(entry => {
                // We fetch the original entry to update it
                const getRequest = store.get(entry.id);
                getRequest.onsuccess = (event) => {
                    const record = event.target.result;
                    if (record) {
                        record.sent_status = 1; // 1 = Sent
                        store.put(record);
                    }
                };
            });

            transaction.oncomplete = () => resolve();
            transaction.onerror = (event) => reject(event.target.error);
        });
    }

    /**
     * Removes sent logs older than X days
     */
    async function cleanupOldLogs(days = 7) {
        const db = await initLogDB();
        const cutoff = Date.now() - (days * 24 * 60 * 60 * 1000);

        return new Promise((resolve, reject) => {
            const transaction = db.transaction([STORE_NAME], "readwrite");
            const store = transaction.objectStore(STORE_NAME);
            const index = store.index("timestamp");

            const range = IDBKeyRange.upperBound(cutoff);
            const request = index.openCursor(range);

            request.onsuccess = (event) => {
                const cursor = event.target.result;
                if (cursor) {
                    const record = cursor.value;
                    // Only delete if it's already sent (1)
                    if (record.sent_status === 1) {
                        store.delete(cursor.primaryKey);
                    }
                    cursor.continue();
                } else {
                    resolve();
                }
            };

            request.onerror = (event) => reject(event.target.error);
        });
    }

    // Export to global scope
    window.QwintDB = {
        initDB: initLogDB, // Alias to old name for panel.js compatibility if needed, but we used initLogDB in plan
        initLogDB: initLogDB,
        saveLogToIndexedDB: saveLogToIndexedDB,
        getPendingLogs: getPendingLogs,
        markLogsSent: markLogsSent,
        cleanupOldLogs: cleanupOldLogs
    };

    // Auto-init on load
    initLogDB().catch(err => console.error("Auto-init QwintDB failed", err));

})(window);
