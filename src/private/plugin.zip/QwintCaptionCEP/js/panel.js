(function () {
  "use strict";

  var cs = new CSInterface();

  // Storage Keys
  var PROXY_KEY_STORAGE = "qwint.proxyKey";
  var PROXY_URL_STORAGE = "qwint.proxyBaseUrl";
  var DEFAULT_PROXY_URL = "https://qwint-ai.qwintsoft.com/";
  var PROXY_KEY_HEADER = "x-litellm-api-key";

  // Proxy Config (Default values, will be overridden by config.json or localStorage)
  var PROXY_MODEL_NAME = localStorage.getItem("qwint.modelName");
  var PROXY_FILES_PROVIDER = localStorage.getItem("qwint.filesProvider");
  var PROXY_FILES_TARGET_MODEL = localStorage.getItem("qwint.filesTargetModel");
  var PROXY_FILES_PATH = localStorage.getItem("qwint.filesPath");
  var PROXY_CHAT_PATH = localStorage.getItem("qwint.chatPath");
  var API_MAX_FILE_SIZE_MB = 500;
  var PROXY_KEY_HEADER = localStorage.getItem("qwint.keyHeader") || "x-api-key";
  var APP_ID = localStorage.getItem("qwint.appId") || "app_1";
  var LONG_VIDEO_THRESHOLD = parseInt(localStorage.getItem("qwint.longVideoThreshold")) || 1200;
  var MAX_CONCURRENCY = parseInt(localStorage.getItem("qwint.maxConcurrency")) || 1;
  var PROXY_CREDITS_PATH = localStorage.getItem("qwint.creditsPath") || "/v1/credits";
  var DASHBOARD_URL = localStorage.getItem("qwint.dashboardUrl") || "https://qwint-caption.qwintsoft.com/topup";

  // State
  var isProcessing = false;
  var isCancelled = false;
  var currentView = "workflow";
  var lastAudioPath = "";
  var flowStartTime = 0;
  var IS_WINDOWS = (function () {
    try {
      var info = cs.getOSInformation();
      return info && info.indexOf("Windows") >= 0;
    } catch (e) {
      return false;
    }
  })();
  var OUTPUT_DIR = "";
  var currentDuration = 0;

  // SaaS Credit State
  var userCreditSeconds = parseInt(localStorage.getItem("qwint.userCreditSeconds"));
  if (isNaN(userCreditSeconds)) {
    userCreditSeconds = 0; // Default until loaded from config or API
  }
  var usageHistory = [];

  // UI Elements
  var btnMainAction,
    statusPrimary,
    statusSecondary,
    progressContainer,
    progressFill,
    progressMessage;
  var idleTitle, idleSubtitle;
  var proxyKeyInput, proxyUrlInput;
  var logEl;

  // Credit Elements
  var creditBadge, creditModal, modalMsg, btnTopUp, btnModalCancel;
  var btnToggleHistory, historyContainer, historyList;

  // --- Credit Manager Module (Isolated) ---
  var CreditManager = {
    getCredits: function () {
      return userCreditSeconds;
    },
    formatTime: function (totalSeconds) {
      var h = Math.floor(totalSeconds / 3600);
      var m = Math.floor((totalSeconds % 3600) / 60);
      var s = Math.round(totalSeconds % 60);
      if (h > 0) {
        return h + "h " + m + "m " + (s < 10 ? "0" : "") + s + "s";
      }
      return m + "m " + (s < 10 ? "0" : "") + s + "s";
    },
    hasEnough: function (requiredSeconds) {
      return userCreditSeconds >= requiredSeconds;
    },
    deduct: function (seconds, sequenceName) {
      if (seconds <= 0) return;
      var prev = userCreditSeconds;
      userCreditSeconds = Math.max(0, userCreditSeconds - seconds);
      localStorage.setItem("qwint.userCreditSeconds", userCreditSeconds);
      Monitor.log("Credits Deducted", { previous: prev, deducted: seconds, remaining: userCreditSeconds });
      this.logUsage(sequenceName, seconds);
      this.updateUI();
      // NOTE: You can add an API call here to sync deduction to the server
    },
    syncFromAPI: function (callback) {
      var self = this;
      var key = getProxyKey();

      // Handle both absolute and relative URLs
      var url = PROXY_CREDITS_PATH;
      if (url && url.indexOf("http") !== 0) {
        url = getProxyUrl() + url;
      }

      if (!key || !url) {
        if (callback) callback(userCreditSeconds);
        return;
      }

      // Dynamically inject API key if placeholder exists
      url = url.replace("${proxyKey}", encodeURIComponent(key));

      // Part 9: trackedFetch for API Monitoring
      const headerName = localStorage.getItem("qwint.keyHeader") || "x-api-key";
      const options = {
        method: "GET",
        headers: { [headerName]: key },
        timeout: 8000
      };

      if (window.trackedFetch) {
        window.trackedFetch(url, options).then(response => response.json()).then(resp => {
          var newCredits = null;
          if (resp && resp.available_budget !== undefined) {
            newCredits = parseInt(resp.available_budget);
          } else if (resp && resp.available_seconds !== undefined) {
            newCredits = parseInt(resp.available_seconds);
          }
          if (newCredits !== null && !isNaN(newCredits)) {
            userCreditSeconds = newCredits;
            localStorage.setItem("qwint.userCreditSeconds", userCreditSeconds);
            self.updateUI();
            Monitor.log("Credits synced from API", { available: userCreditSeconds });
          }
          if (callback) callback(userCreditSeconds);
        }).catch(err => {
          Monitor.error("Credit API sync failed", { url: url });
          if (callback) callback(userCreditSeconds);
        });
        return;
      }

      xhr.onload = function () {
        try {
          var resp = JSON.parse(xhr.responseText);
          // Support both available_seconds and available_budget as per user request
          var newCredits = null;
          if (resp && resp.available_budget !== undefined) {
            newCredits = parseInt(resp.available_budget);
          } else if (resp && resp.available_seconds !== undefined) {
            newCredits = parseInt(resp.available_seconds);
          }

          if (newCredits !== null && !isNaN(newCredits)) {
            userCreditSeconds = newCredits;
            localStorage.setItem("qwint.userCreditSeconds", userCreditSeconds);
            self.updateUI();
            Monitor.log("Credits synced from API", { available: userCreditSeconds });
          }
        } catch (e) {
          Monitor.error("Failed to parse credit API response", e);
        }
        if (callback) callback(userCreditSeconds);
      };

      xhr.onerror = function () {
        Monitor.error("Credit API sync failed", { url: url });
        if (callback) callback(userCreditSeconds);
      };

      xhr.send();
    },
    logUsage: function (name, seconds) {
      var entry = {
        name: name || "Active Sequence",
        used: this.formatTime(seconds),
        date:
          new Date().toLocaleString().split(",")[0] +
          " " +
          new Date().toLocaleTimeString([], {
            hour: "2-digit",
            minute: "2-digit",
            hour12: false,
          }),
        remaining: this.formatTime(userCreditSeconds),
      };
      usageHistory.unshift(entry);
      this.updateHistoryUI();
    },
    updateUI: function () {
      if (!creditBadge) return;
      creditBadge.textContent =
        "Credits: " + this.formatTime(userCreditSeconds);
      creditBadge.classList.remove("credit-warning", "credit-danger");
      if (userCreditSeconds === 0) creditBadge.classList.add("credit-danger");
      else if (userCreditSeconds < 600)
        creditBadge.classList.add("credit-warning");
    },
    updateHistoryUI: function () {
      if (!historyList) return;
      if (usageHistory.length === 0) {
        historyList.innerHTML =
          '<div class="history-empty">No history record.</div>';
        return;
      }
      var html = "";
      for (var i = 0; i < usageHistory.length; i++) {
        var it = usageHistory[i];
        html +=
          '<div class="history-item">' +
          '<div class="history-name">' +
          it.name +
          "</div>" +
          '<div class="history-meta">' +
          "<span>Used: " +
          it.used +
          "</span>" +
          "<span>" +
          it.date +
          "</span>" +
          "</div>" +
          '<div class="history-meta" style="margin-top:2px; font-size:10px;">' +
          "<span>Remaining: " +
          it.remaining +
          "</span>" +
          "</div>" +
          "</div>";
      }
      historyList.innerHTML = html;
    },
  };

  /**
   * Loads configuration from config.json file
   */
  function loadConfig() {
    try {
      var extPath = cs.getSystemPath(SystemPath.EXTENSION);
      var configPath = extPath + "/config.json";
      var result = window.cep.fs.readFile(configPath);
      if (result.err === 0) {
        var config = JSON.parse(result.data);
        if (config.proxyKey) {
          localStorage.setItem(PROXY_KEY_STORAGE, config.proxyKey);
          if (proxyKeyInput) proxyKeyInput.value = config.proxyKey;
        }
        if (config.proxyBaseUrl) {
          localStorage.setItem(PROXY_URL_STORAGE, config.proxyBaseUrl);
          if (proxyUrlInput) proxyUrlInput.value = config.proxyBaseUrl;
        }

        // Persist Internal Constants to localStorage so they survive file deletion
        if (config.proxyModelName) {
          PROXY_MODEL_NAME = config.proxyModelName;
          localStorage.setItem("qwint.modelName", PROXY_MODEL_NAME);
        }
        if (config.proxyFilesProvider) {
          PROXY_FILES_PROVIDER = config.proxyFilesProvider;
          localStorage.setItem("qwint.filesProvider", PROXY_FILES_PROVIDER);
        }
        if (config.proxyFilesTargetModel) {
          PROXY_FILES_TARGET_MODEL = config.proxyFilesTargetModel;
          localStorage.setItem(
            "qwint.filesTargetModel",
            PROXY_FILES_TARGET_MODEL,
          );
        }
        if (config.proxyFilesPath) {
          PROXY_FILES_PATH = config.proxyFilesPath;
          localStorage.setItem("qwint.filesPath", PROXY_FILES_PATH);
        }
        if (config.proxyChatPath) {
          PROXY_CHAT_PATH = config.proxyChatPath;
          localStorage.setItem("qwint.chatPath", PROXY_CHAT_PATH);
        }
        if (config.proxyKeyHeader) {
          PROXY_KEY_HEADER = config.proxyKeyHeader;
          localStorage.setItem("qwint.keyHeader", PROXY_KEY_HEADER);
        }
        if (config.appId) {
          APP_ID = config.appId;
          localStorage.setItem("qwint.appId", APP_ID);
        }
        if (config.longVideoThreshold) {
          LONG_VIDEO_THRESHOLD = parseInt(config.longVideoThreshold);
          localStorage.setItem("qwint.longVideoThreshold", LONG_VIDEO_THRESHOLD);
        }
        if (config.maxConcurrency) {
          MAX_CONCURRENCY = parseInt(config.maxConcurrency);
          localStorage.setItem("qwint.maxConcurrency", MAX_CONCURRENCY);
        }
        if (config.proxyCreditsPath) {
          PROXY_CREDITS_PATH = config.proxyCreditsPath;
          localStorage.setItem("qwint.creditsPath", PROXY_CREDITS_PATH);
        }
        if (config.dashboardUrl) {
          DASHBOARD_URL = config.dashboardUrl;
          localStorage.setItem("qwint.dashboardUrl", DASHBOARD_URL);
        }
        if (config.ooOrg) {
          localStorage.setItem("qwint.ooOrg", config.ooOrg);
        }
        if (config.ooStream) {
          localStorage.setItem("qwint.ooStream", config.ooStream);
        }
        if (config.ooToken) {
          localStorage.setItem("qwint.ooToken", config.ooToken);
        }
        if (config.ooBaseUrl) {
          localStorage.setItem("qwint.ooBaseUrl", config.ooBaseUrl);
        }
        if (config.available_seconds !== undefined) {
          var avail = parseInt(config.available_seconds) || 0;
          if (localStorage.getItem("qwint.userCreditSeconds") === null) {
            userCreditSeconds = avail;
            localStorage.setItem("qwint.userCreditSeconds", userCreditSeconds);
          }
        }

        Monitor.log(
          "Configuration loaded and persisted from config.json. Deleting file...",
        );

        // Auto-delete the file after successful loading
        var delRes = window.cep.fs.deleteFile(configPath);
        if (delRes.err !== 0) {
          Monitor.warn(
            "Could not delete config.json (maybe permissions?): " + delRes.err,
          );
        } else {
          Monitor.log("config.json successfully deleted.");
        }
      }
    } catch (e) {
      if (e.name !== "SyntaxError") {
        // Ignore if file exists but is empty/unreadable
        Monitor.error("Failed to process config.json", e);
      }
    }
  }

  // --- Core Utility Functions (REPLYING TO STEP 278) ---

  function computeOutputDir() {
    var base = cs.getSystemPath(SystemPath.USER_DATA);
    if (!base || base === "invalidParam")
      base = cs.getSystemPath(SystemPath.TEMP);
    var cleanBase = base.replace(/[\\/]+$/, "").replace(/\\/g, "/");
    return cleanBase + "/subtitle-generator";
  }

  function appendLog(message, level) {
    if (!logEl) return;
    var d = new Date();
    var line =
      "[" +
      d.toLocaleTimeString() +
      "] " +
      (level === "error" ? "ERROR: " : "") +
      message +
      "\n";
    logEl.textContent += line;
    logEl.scrollTop = logEl.scrollHeight;
  }

  function parseResult(result) {
    if (!result) return null;
    try {
      var p = JSON.parse(result);
      if (p && (p.ok === "true" || p.ok === "1")) p.ok = true;
      if (p && (p.ok === "false" || p.ok === "0")) p.ok = false;
      return p;
    } catch (e) {
      var obj = {};
      var okMatch = result.match(/"ok"\s*:\s*"?(true|false|1|0)"?/);
      if (okMatch) obj.ok = okMatch[1] === "true" || okMatch[1] === "1";
      var msgMatch = result.match(/"message"\s*:\s*"([^"]+)"/);
      if (msgMatch) obj.message = msgMatch[1];
      var detMatch = result.match(/"details"\s*:\s*"([^"]+)"/);
      if (detMatch) obj.details = detMatch[1];
      var pathMatch = result.match(/"path"\s*:\s*"([^"]+)"/);
      if (pathMatch) obj.path = pathMatch[1];
      return obj.ok !== undefined ? obj : null;
    }
  }

  function normalizePath(path) {
    return path ? path.replace(/\\/g, "/") : "";
  }

  function toNativePath(path) {
    if (!path) return "";
    return IS_WINDOWS ? path.replace(/\//g, "\\") : path.replace(/\\/g, "/");
  }

  // --- Diagnostic & Monitoring Module ---
  var Monitor = {
    logs: [],
    log: function (msg, data) {
      var entry = {
        timestamp: new Date().toISOString(),
        message: msg,
        data: data,
      };
      this.logs.push(entry);
      var text =
        "[" +
        new Date().toLocaleTimeString() +
        "] " +
        msg +
        (data ? " " + JSON.stringify(data) : "");
      appendLog(text);
      console.log("[QwintMonitor]", msg, data || "");

      // New Logging Infrastructure Integration
      if (window.QwintLogger) {
        window.QwintLogger.log("INFO", msg, msg, getLogMeta(data));
      }
    },
    error: function (msg, err) {
      var data = err;
      if (err instanceof Error)
        data = { message: err.message, stack: err.stack };
      this.log("ERROR: " + msg, data);

      // New Logging Infrastructure Integration
      if (window.QwintLogger) {
        window.QwintLogger.log("ERROR", msg, msg, getLogMeta(data));
      }
    },
    getMemory: function () {
      try {
        if (typeof process !== "undefined" && process.memoryUsage) {
          var mem = process.memoryUsage();
          return {
            rss: (mem.rss / 1024 / 1024).toFixed(2) + "MB",
            heap: (mem.heapUsed / 1024 / 1024).toFixed(2) + "MB",
          };
        }
      } catch (e) { }
      return "N/A";
    },
  };

  // --- UI State Controller ---

  function setUIState(state, message) {
    if (state === "idle") {
      btnMainAction.textContent = "✦ Generate Captions";
      btnMainAction.classList.remove("is-stop");
      if (idleTitle) idleTitle.textContent = "Ready to transcribe";
      if (idleSubtitle) idleSubtitle.textContent = "Select a sequence to start";
      statusPrimary.textContent = "Ready to generate subtitles.";
      statusSecondary.textContent = "";
      progressContainer.style.visibility = "hidden";
      updateProgress(0);
    } else if (state === "running") {
      btnMainAction.textContent = "Stop";
      btnMainAction.classList.add("is-stop");
      statusPrimary.textContent = "Started";
      statusSecondary.textContent = "In Progress...";
      progressContainer.style.visibility = "visible";
    } else if (state === "completed") {
      btnMainAction.textContent = "✦ Generate Captions";
      btnMainAction.classList.remove("is-stop");
      if (idleTitle) idleTitle.textContent = "Success!";
      if (idleSubtitle)
        idleSubtitle.textContent = "Subtitles imported successfully";
      statusPrimary.textContent = "Completed Successfully";
      statusSecondary.textContent = "";
      updateProgress(100);
    } else if (state === "error") {
      btnMainAction.textContent = "✦ Retry";
      btnMainAction.classList.remove("is-stop");
      if (idleTitle) idleTitle.textContent = "Process Interrupted";
      if (idleSubtitle)
        idleSubtitle.textContent =
          message || "Please check your sequence and try again.";
      statusPrimary.textContent = "Something went wrong.";
      statusSecondary.textContent =
        message || "Please check your sequence and try again.";
      progressContainer.style.visibility = "hidden";
    } else if (state === "stopped") {
      btnMainAction.textContent = "✦ Generate Captions";
      btnMainAction.classList.remove("is-stop");
      if (idleTitle) idleTitle.textContent = "Process Stopped";
      if (idleSubtitle) idleSubtitle.textContent = "Stopped by user.";
      statusPrimary.textContent = "Stopped by user.";
      statusSecondary.textContent = "";
      progressContainer.style.visibility = "hidden";
    }
  }

  var currentStage = { start: 0, end: 100 };
  function updateProgress(percent, msg) {
    var globalPercent = percent;
    if (percent !== null && currentStage) {
      globalPercent = currentStage.start + (percent / 100) * (currentStage.end - currentStage.start);
    }

    if (progressFill && globalPercent !== null)
      progressFill.style.width = globalPercent.toFixed(1) + "%";
    if (msg && progressMessage) progressMessage.textContent = msg;

    var logMsg = (globalPercent !== null ? globalPercent.toFixed(1) + "% " : "") + (msg || "");
    appendLog("Progress: " + logMsg);
  }

  function setProgressStage(start, end) {
    currentStage = { start: start, end: end };
  }

  function handleFlowError(msg, customDuration) {
    isProcessing = false;
    setUIState("error", msg);
    appendLog("Error: " + msg);
    if (typeof logActivity === "function") {
      logActivity("Process Error: " + msg, false, (customDuration !== undefined ? customDuration : currentDuration));
    }
  }

  function startGenerateFlow() {
    var isTrimmed = false;
    const flowStart = performance.now();

    if (window.qwintLog) {
      window.qwintLog("info", "button_clicked", { id: "btn-main-action" });
    }

    if (isProcessing) {
      isCancelled = true;
      isProcessing = false;
      setUIState("stopped");
      appendLog("Process cancelled by user.");
      if (typeof logActivity === "function") {
        logActivity("Process Cancelled by User", false);
      }
      return;
    }

    currentDuration = 0; // Reset
    if (typeof logActivity === "function") {
      logActivity("Generate Captions Started", true, 0);
    }

    var key = getProxyKey();
    if (!key) {
      alert("Missing Proxy Access Key. Please go to Settings.");
      setActiveView("settings");
      return;
    }

    isProcessing = true;
    isCancelled = false;
    flowStartTime = Date.now();
    setUIState("running");
    setProgressStage(0, 100);
    updateProgress(0, "Preparing your selection...");

    // 1. Validate (0-10%)
    setProgressStage(0, 10);
    updateProgress(50);
    cs.evalScript("qwint_validateSequence()", function (res) {
      if (isCancelled) return;
      var parsed = parseResult(res);
      if (!parsed || !parsed.ok)
        return handleFlowError(
          parsed ? parsed.message : "No active sequence found.",
        );

      var sequenceName = parsed.message.replace("Sequence validated: ", "");
      if (window.qwintLog) {
        window.qwintLog("info", "analysis_started", { sequenceName: sequenceName });
      }
      const analysisStartTime = performance.now();

      // 2. Duration (10-15%)
      setProgressStage(10, 15);
      updateProgress(0);
      cs.evalScript("qwint_getSequenceDurationSeconds()", function (resDur) {
        if (isCancelled) return;
        var durObj = parseResult(resDur);
        if (!durObj || !durObj.ok)
          return handleFlowError(
            durObj ? durObj.message : "Duration detection failed.",
          );
        var duration = parseFloat(durObj.details) || 0;
        var durationSeconds = Math.ceil(duration);
        var originalDurationSeconds = durationSeconds;
        var isTrimmed = false;

        // --- FREE USAGE GUARD LAYER ---
        var freeLimit = CreditManager.getCredits();
        Monitor.log("Processing Limit Check", { balance: freeLimit, videoDuration: durationSeconds });

        if (freeLimit <= 0) {
          isProcessing = false;
          showCreditModal(CreditManager.getCredits(), durationSeconds);
          setUIState("idle");
          return;
        }

        if (durationSeconds > freeLimit) {
          durationSeconds = freeLimit;
          duration = freeLimit;
          isTrimmed = true;
          Monitor.log("Free limit applied (trimmed)", { original: originalDurationSeconds, allowed: freeLimit });
        }
        currentDuration = durationSeconds;

        // --- ADDITIVE SAAS CREDIT GUARD ---
        if (!CreditManager.hasEnough(durationSeconds)) {
          isProcessing = false;
          showCreditModal(CreditManager.getCredits(), durationSeconds);
          setUIState("idle");
          return;
        }

        // --- PERFORMANCE OPTIMIZATION LAYER ---
        if (durationSeconds > LONG_VIDEO_THRESHOLD) {
          return startOptimizedLongVideoFlow(durationSeconds, sequenceName, isTrimmed);
        }

        // 3. Export (15-40%)
        setProgressStage(15, 40);
        updateProgress(0, "Exporting audio...");
        var exportScript = isTrimmed ? 'qwint_exportAudioSegment(0, ' + durationSeconds + ')' : "qwint_exportAudio()";
        cs.evalScript(exportScript, function (resExp) {
          if (isCancelled) return;
          var expObj = parseResult(resExp);
          if (!expObj || !expObj.ok)
            return handleFlowError("Failed to export audio.");
          lastAudioPath = normalizePath(expObj.path);

          // 4. Upload (40-65%)
          setProgressStage(40, 65);
          updateProgress(0, "Starting upload...");
          setTimeout(function () {
            if (isCancelled) return;
            verifyAndReadAudioFile(lastAudioPath, function (err, bytes) {
              if (err) return handleFlowError(err.message);

              updateProgress(10, "Reading audio file...");
              uploadAudioToProxy(
                key,
                getProxyUrl(),
                "audio/wav",
                bytes,
                function (errUp, fileId) {
                  if (errUp) return handleFlowError(errUp.message);

                  // 5. Transcribe (65-90%)
                  setProgressStage(65, 90);
                  updateProgress(0, "Waiting for AI transcription...");

                  if (window.qwintLog) {
                    window.qwintLog("info", "analysis_completed", { duration_ms: performance.now() - analysisStartTime });
                    window.qwintLog("info", "transcription_started", { fileId: fileId });
                  }
                  const transStart = performance.now();

                  requestSrtFromProxy(
                    key,
                    getProxyUrl(),
                    fileId,
                    function (errTr, srtText) {
                      if (errTr) {
                        if (window.QwintLogger) {
                          var errEvent = "API_ERROR";
                          if (errTr.status === 500) errEvent = "API_500";
                          else if (errTr.timeout) errEvent = "API_TIMEOUT";
                          window.QwintLogger.log("ERROR", errEvent, "Transcription request failed", getLogMeta({ error: errTr }));
                        }
                        return handleFlowError(errTr.message);
                      }

                      if (!srtText || srtText.trim() === "") {
                        if (window.QwintLogger) {
                          window.QwintLogger.log("ERROR", "EMPTY_SRT", "AI returned empty SRT content", getLogMeta());
                        }
                        return handleFlowError("AI returned no results.");
                      }

                      if (window.qwintLog) {
                        window.qwintLog("info", "transcription_completed", { duration_ms: performance.now() - transStart });
                        window.qwintLog("info", "transcription_time", { duration_ms: performance.now() - transStart });
                        window.qwintLog("info", "subtitle_generation_started", {});
                      }
                      const subtitleStart = performance.now();

                      // 6. Create SRT (90-95%)
                      setProgressStage(90, 95);
                      updateProgress(0, "Generating SRT file...");
                      var srtName = "subtitles_" + Date.now() + ".srt";
                      var srtPath = OUTPUT_DIR + "/" + srtName;
                      var srtContent = normalizeSrtText(srtText, duration);
                      var write = window.cep.fs.writeFile(
                        toNativePath(srtPath),
                        srtContent,
                      );
                      if (write.err !== 0)
                        return handleFlowError("Failed to write SRT file.");

                      // 7. Import (95-100%)
                      setProgressStage(95, 100);
                      updateProgress(0, "Importing subtitles...");
                      var script =
                        'qwint_importSubtitles("' +
                        srtPath.replace(/\\/g, "/") +
                        '")';
                      cs.evalScript(script, function (resImp) {
                        if (isCancelled) return;
                        if (!parseResult(resImp).ok)
                          return handleFlowError("Failed to import captions.");

                        // --- ADDITIVE SUCCESS HOOK ---
                        CreditManager.syncFromAPI();

                        // 8. Done
                        updateProgress(100);
                        isProcessing = false;
                        setUIState("completed");
                        appendLog("Success! Subtitles imported.");

                        if (isTrimmed) {
                          if (idleSubtitle) idleSubtitle.textContent = durationSeconds + " seconds of video generated successfully as per your available credits.";
                        }

                        if (typeof logActivity === "function") {
                          logActivity(
                            "Generate Captions Successful (" + sequenceName + ")",
                            true,
                            durationSeconds,
                          );
                        }
                      });
                    },
                  );
                },
              );
            });
          }, 1000);
        });
      });
    });
  }

  // --- Long Video Performance Optimization Pipeline ---
  var CHUNK_DURATION = 600; // Default 10 minutes

  function pad2(n) {
    return (n < 10 ? "0" : "") + n;
  }
  function pad3(n) {
    return (n < 100 ? (n < 10 ? "00" : "0") : "") + n;
  }

  // Parses ANY timestamp variant the AI might produce
  // Handles: HH:MM:SS,mmm | MM:SS,mmm | MM:SS:mmm | HH:MM:SS | MM:SS
  //          M:SS,mmm | M:SS:mm | and any mix of these
  function parseSrtTime(t) {
    t = (t || "").trim();

    // First, normalize: if there's a comma, split on it to separate ms
    var mainPart = t;
    var msPart = 0;
    var commaIdx = t.indexOf(",");
    if (commaIdx !== -1) {
      mainPart = t.substring(0, commaIdx);
      var msStr = t.substring(commaIdx + 1);
      // Pad or trim to 3 digits: "90" -> 900, "1" -> 100, "690" -> 690
      if (msStr.length === 1) msStr = msStr + "00";
      else if (msStr.length === 2) msStr = msStr + "0";
      else if (msStr.length > 3) msStr = msStr.substring(0, 3);
      msPart = parseInt(msStr) || 0;
    }

    var parts = mainPart.split(":");
    var hr = 0,
      min = 0,
      sec = 0;

    if (parts.length >= 3) {
      // Could be HH:MM:SS or MM:SS:mmm
      var lastVal = parseInt(parts[parts.length - 1]) || 0;
      var lastStr = parts[parts.length - 1];

      if (commaIdx === -1 && (lastVal > 59 || lastStr.length === 3)) {
        // No comma was present AND last part looks like ms (>59 or 3 digits)
        // This is MM:SS:mmm format (AI used colon instead of comma)
        min = parseInt(parts[0]) || 0;
        sec = parseInt(parts[1]) || 0;
        // Pad ms: "90" -> 900, "000" -> 0
        var msRaw = lastStr;
        if (msRaw.length === 1) msRaw = msRaw + "00";
        else if (msRaw.length === 2) msRaw = msRaw + "0";
        msPart = parseInt(msRaw) || 0;
      } else if (commaIdx === -1 && lastStr.length <= 2 && lastVal <= 59) {
        // No comma, last part is ≤59 and ≤2 digits → HH:MM:SS (no ms)
        hr = parseInt(parts[0]) || 0;
        min = parseInt(parts[1]) || 0;
        sec = lastVal;
      } else {
        // Has comma, standard HH:MM:SS (ms already extracted above)
        hr = parseInt(parts[0]) || 0;
        min = parseInt(parts[1]) || 0;
        sec = parseInt(parts[2]) || 0;
      }
    } else if (parts.length === 2) {
      // MM:SS (with or without comma-ms already extracted)
      min = parseInt(parts[0]) || 0;
      var secVal = parseInt(parts[1]) || 0;

      if (commaIdx === -1 && secVal > 59) {
        // No comma and value >59 → this IS the ms value? unlikely but handle
        sec = 0;
        msPart = secVal;
      } else {
        sec = secVal;
      }
    } else if (parts.length === 1) {
      // Just seconds (rare)
      sec = parseInt(parts[0]) || 0;
    }

    return hr * 3600 + min * 60 + sec + msPart / 1000;
  }

  function formatSrtTime(ts) {
    if (ts < 0) ts = 0;
    var ms = Math.round((ts % 1) * 1000);
    var s = Math.floor(ts) % 60;
    var m = Math.floor(ts / 60) % 60;
    var h = Math.floor(ts / 3600);
    return pad2(h) + ":" + pad2(m) + ":" + pad2(s) + "," + pad3(ms);
  }

  // Normalize ALL broken AI timestamp formats to standard HH:MM:SS,mmm --> HH:MM:SS,mmm
  // Universal approach: any line with " --> " is a timestamp line.
  // Extract both sides, parse them (parseSrtTime handles every format), reformat.
  function normalizeSrtTimestamps(text, maxDuration) {
    var lines = text.split("\n");
    var out = [];
    for (var i = 0; i < lines.length; i++) {
      var line = lines[i];

      // Universal: if line contains " --> ", treat it as a timestamp line
      var arrowIdx = line.indexOf("-->");
      if (arrowIdx !== -1) {
        var rawStart = line.substring(0, arrowIdx).trim();
        var rawEnd = line.substring(arrowIdx + 3).trim();

        // Only process if both sides look like timestamps (contain at least a digit and colon)
        if (
          /\d/.test(rawStart) &&
          /\d/.test(rawEnd) &&
          /[:\,]/.test(rawStart)
        ) {
          var startSec = parseSrtTime(rawStart);
          var endSec = parseSrtTime(rawEnd);

          // Clamp to video duration if provided
          if (maxDuration && maxDuration > 0) {
            if (startSec > maxDuration) startSec = maxDuration;
            if (endSec > maxDuration) endSec = maxDuration;
          }
          // If end is before/equal to start, set end = start + 3s
          if (endSec <= startSec) {
            endSec = startSec + 3;
            if (maxDuration && endSec > maxDuration) endSec = maxDuration;
          }
          line = formatSrtTime(startSec) + " --> " + formatSrtTime(endSec);
        }
      }
      out.push(line);
    }
    return out.join("\n");
  }

  function offsetSrt(text, offset, maxDuration) {
    // Always normalize first so regex reliably matches HH:MM:SS,mmm
    var normalized = normalizeSrtTimestamps(text, maxDuration);
    if (offset === 0) return normalized;
    var cap = maxDuration || 0;
    return normalized.replace(
      /(\d{2}:\d{2}:\d{2},\d{3}) --> (\d{2}:\d{2}:\d{2},\d{3})/g,
      function (m, s, e) {
        var newStart = parseSrtTime(s) + offset;
        var newEnd = parseSrtTime(e) + offset;
        if (cap > 0) {
          if (newStart > cap) newStart = cap;
          if (newEnd > cap) newEnd = cap;
        }
        return formatSrtTime(newStart) + " --> " + formatSrtTime(newEnd);
      },
    );
  }

  // ─── WAV SPLITTER (Node.js) ─────────────────────────────────────
  // Reads actual WAV header so splitting is correct regardless of export format

  function parseWavHeader(fs, srcPath) {
    // WAV header: RIFF(4) + FileSize(4) + WAVE(4) + fmt (4) + fmtSize(4) = 20 bytes minimum
    // fmt chunk: AudioFmt(2)+Channels(2)+SampleRate(4)+ByteRate(4)+BlockAlign(2)+BitsPerSample(2) = 16 bytes
    // ByteRate is at offset 28: SampleRate × Channels × BitsPerSample/8
    // data chunk offset: scan after fmt chunk for "data" marker
    var scanBuf = Buffer.alloc(512); // Read first 512 bytes to find all chunks
    var fd = fs.openSync(srcPath, "r");
    var bytesRead = fs.readSync(fd, scanBuf, 0, 512, 0);
    fs.closeSync(fd);

    // Validate RIFF WAV
    var riff = scanBuf.toString("ascii", 0, 4);
    var wave = scanBuf.toString("ascii", 8, 12);
    if (riff !== "RIFF" || wave !== "WAVE") {
      throw new Error("Not a valid WAV file (RIFF/WAVE markers missing)");
    }

    // Read byte rate from fmt chunk (always at fixed offset 28 for standard WAV)
    var byteRate = scanBuf.readUInt32LE(28);
    if (!byteRate || byteRate < 8000) {
      throw new Error("WAV byte rate invalid: " + byteRate);
    }

    // Find 'data' chunk by scanning (handles WAV files with metadata/LIST chunks)
    var dataOffset = -1;
    var dataSize = 0;
    for (var i = 12; i < bytesRead - 8; i++) {
      if (
        scanBuf[i] === 0x64 &&
        scanBuf[i + 1] === 0x61 &&
        scanBuf[i + 2] === 0x74 &&
        scanBuf[i + 3] === 0x61
      ) {
        // 'data'
        dataOffset = i + 8; // Skip 'data' marker (4) + size field (4)
        dataSize = scanBuf.readUInt32LE(i + 4);
        break;
      }
    }
    if (dataOffset < 0) {
      throw new Error("Could not find data chunk in WAV file");
    }

    return {
      byteRate: byteRate,
      dataOffset: dataOffset,
      headerSize: dataOffset,
    };
  }

  function splitWavChunk(fs, srcPath, chunkIdx, startSec, durationSec, outDir) {
    // Parse actual WAV format from file header (no hardcoded assumptions)
    var wavInfo = parseWavHeader(fs, srcPath);
    var byteRate = wavInfo.byteRate;
    var dataOffset = wavInfo.dataOffset;

    var startByte = dataOffset + Math.floor(startSec * byteRate);
    var chunkBytes = Math.floor(durationSec * byteRate);

    // Read the original WAV header bytes (everything before data)
    var headerBuf = Buffer.alloc(dataOffset);
    var fd = fs.openSync(srcPath, "r");
    fs.readSync(fd, headerBuf, 0, dataOffset, 0);

    // Read chunk PCM data
    var dataBuf = Buffer.alloc(chunkBytes);
    var bytesRead = fs.readSync(fd, dataBuf, 0, chunkBytes, startByte);
    fs.closeSync(fd);

    if (bytesRead < chunkBytes) {
      dataBuf = dataBuf.slice(0, bytesRead); // Trim last chunk
    }

    // Patch WAV header: update RIFF file size and data chunk size
    var newDataSize = dataBuf.length;
    var newFileSize = dataOffset - 8 + newDataSize;
    headerBuf.writeUInt32LE(newFileSize, 4); // RIFF chunk size
    headerBuf.writeUInt32LE(newDataSize, dataOffset - 4); // data chunk size

    // Write chunk WAV file
    var chunkPath =
      outDir + "/wav_chunk_" + chunkIdx + "_" + Date.now() + ".wav";
    var outFd = fs.openSync(chunkPath, "w");
    fs.writeSync(outFd, headerBuf, 0, dataOffset);
    fs.writeSync(outFd, dataBuf, 0, dataBuf.length);
    fs.closeSync(outFd);

    Monitor.log("WAV Chunk Written", {
      chunk: chunkIdx,
      byteRate: byteRate,
      dataOffset: dataOffset,
      startSec: startSec,
      sizeMB: (dataBuf.length / 1024 / 1024).toFixed(2),
    });

    return chunkPath;
  }

  function startOptimizedLongVideoFlow(totalDuration, sequenceName, isTrimmed) {
    var key = getProxyKey();
    var url = getProxyUrl();
    var chunkDuration = 60; // 1 minute chunks for maximum accuracy as requested
    var totalChunks = Math.ceil(totalDuration / chunkDuration);
    var allSegments = new Array(totalChunks);
    var completedCount = 0;
    var activeCount = 0;
    var nextIdx = 0;
    var maxConcurrency = MAX_CONCURRENCY;
    var masterAudioPath = null;

    Monitor.log("ADAPTIVE ENGINE START", {
      totalDuration: totalDuration,
      chunkDuration: chunkDuration,
      totalChunks: totalChunks,
      mode: "Direct SRT per Chunk + Offset Merge",
    });

    // ── STEP 1: Export full audio ONCE (5-20%) ──────────────────────────────
    setProgressStage(5, 20);
    updateProgress(0, "Exporting full audio (16kHz Mono)...");
    var exportScript = isTrimmed ? "qwint_exportAudioSegmentOptimized(0, " + totalDuration + ")" : "qwint_exportAudioOptimized()";
    cs.evalScript(exportScript, function (res) {
      if (isCancelled) return;
      var expObj = parseResult(res);
      if (!expObj || !expObj.ok)
        return handleFlowError(
          "Full audio export failed: " + (expObj ? expObj.message : "unknown"),
        );

      masterAudioPath = toNativePath(normalizePath(expObj.path));
      Monitor.log("Full Export Done", { path: masterAudioPath });

      // ── STEP 2: Processing Stage (20-95%) ──
      setProgressStage(20, 95);

      // Check if Node.js is available for WAV splitting
      if (typeof require === "undefined") {
        Monitor.log("Node not available - falling back to single-pass upload");
        return startSinglePassTranscription(
          key,
          url,
          masterAudioPath,
          totalDuration,
          sequenceName,
        );
      }

      // Start the batch queue
      for (var i = 0; i < maxConcurrency; i++) {
        launchNextChunk();
      }
    });

    function launchNextChunk() {
      if (isCancelled || nextIdx >= totalChunks) return;
      if (activeCount >= maxConcurrency) return;

      var currentIdx = nextIdx++;
      activeCount++;
      processChunk(currentIdx);
    }

    // ── STEP 2: Split and process chunks (Managed Batch) ────────────
    function processChunk(idx) {
      if (isCancelled) {
        activeCount--;
        return;
      }

      var chunkNum = idx + 1;
      var startSec = idx * chunkDuration;
      var actualDuration = Math.min(chunkDuration, totalDuration - startSec);

      updateProgress(null, "Preparing Chunk " + chunkNum + "...");
      Monitor.log("Seeding Batch Chunk", { chunk: chunkNum, start: startSec });

      // Split WAV locally using Node.js (Synchronous to avoid IO collision)
      try {
        var fs = require("fs");
        var path = require("path");
        var outDir = path.dirname(masterAudioPath);
        var chunkPath = splitWavChunk(
          fs,
          masterAudioPath,
          chunkNum,
          startSec,
          actualDuration,
          outDir,
        );

        uploadAudioStreaming(key, url, chunkPath, function (errUp, fileId) {
          // Clean up chunk file after upload
          try {
            fs.unlinkSync(chunkPath);
          } catch (e) { }
          if (errUp) {
            activeCount--;
            launchNextChunk(); // Keep queue moving even on error
            return handleFlowError(
              "Chunk " + chunkNum + " upload failed: " + errUp.message,
              actualDuration,
            );
          }
          handleChunkTranscription(fileId, startSec, actualDuration, idx);
        }, 1, true); // true = isParallel
      } catch (nodeErr) {
        activeCount--;
        launchNextChunk();
        Monitor.error("WAV Split Error", nodeErr);
        handleFlowError("Failed to split audio chunk: " + nodeErr.message, 60);
      }
    }

    function handleChunkTranscription(fileId, offset, duration, idx) {
      var chunkNum = idx + 1;
      updateProgress(null, "Transcribing Chunk " + chunkNum + "...");

      // Explicit format example in prompt eliminates most AI formatting errors
      var prompt =
        "You are a strict audio transcription engine.\n" +
        "Your ONLY task is to convert the PROVIDED AUDIO into accurate SRT subtitles.\n" +
        "\n" +
        "OUTPUT FORMAT (follow exactly, no deviations):\n" +
        "1\n" +
        "00:00:00,000 --> 00:00:03,000\n" +
        "Exact spoken words here\n" +
        "\n" +
        "2\n" +
        "00:00:03,000 --> 00:00:06,000\n" +
        "Next exact spoken words\n" +
        "\n" +
        "CRITICAL RULES:\n" +
        "- Transcribe EXACTLY what is spoken.\n" +
        "- DO NOT paraphrase.\n" +
        "- DO NOT summarize.\n" +
        "- DO NOT improve grammar.\n" +
        "- DO NOT add missing words.\n" +
        "- If audio is unclear, write [inaudible].\n" +
        "- NEVER invent content.\n" +
        "\n" +
        "TIMESTAMP RULES:\n" +
        "- Start at 00:00:00,000.\n" +
        "- Use real audio timing only.\n" +
        "- Timestamps must be strictly sequential.\n" +
        "- NO jumping forward in time.\n" +
        "- NO unexplained gaps > 3 seconds.\n" +
        "- LABEL non-speech gaps (e.g., [silence], [music], [laughter]).\n" +
        "- Each caption must start exactly when the previous one ends (unless silence exists).\n" +
        "- Format: HH:MM:SS,mmm (comma before milliseconds).\n" +
        '- Separator must be " --> " (space arrow space).\n' +
        "- ALWAYS include hours (00: even if zero).\n" +
        "\n" +
        "CAPTION RULES:\n" +
        "- Maximum 8–12 words per caption.\n" +
        "- Split at natural pauses.\n" +
        "- Preferred duration: 2–4 seconds per caption.\n" +
        "- Maximum 2 lines per caption.\n" +
        "- Do NOT break words in the middle.\n" +
        "\n" +
        "STRUCTURE RULES:\n" +
        "- Number captions starting from 1.\n" +
        "- Increment by 1 with no skips or duplicates.\n" +
        "- Include one blank line between captions.\n" +
        "\n" +
        "OUTPUT RESTRICTIONS:\n" +
        "- Output RAW SRT only.\n" +
        "- NO markdown.\n" +
        "- NO code blocks.\n" +
        "- NO explanations.\n" +
        "- NO extra text before or after.\n" +
        "- Stop immediately when audio ends.\n";

      function validateAndRecord(srtText, isRetry) {
        var lines = srtText.split("\n");
        var hasBrokenLine = false;
        var tsLines = 0;
        var maxTsFound = 0;
        for (var i = 0; i < lines.length; i++) {
          var line = lines[i].trim();
          if (line.indexOf("-->") !== -1) {
            tsLines++;
            var parts = line.split("-->");
            if (parts.length !== 2 || parts[1].trim().length < 8) {
              hasBrokenLine = true;
              break;
            }
            var endVal = parseSrtTime(parts[1].trim());
            if (endVal > maxTsFound) maxTsFound = endVal;
          } else if (line.match(/^\d{1,2}:/) && line.length < 10) {
            // PARTIAL TIMESTAMP: Detected something like "00:0" or "12:"
            hasBrokenLine = true;
            break;
          }
        }

        // DURATION GUARD: If AI only covered the first 20s of a 60s chunk and didn't label silence
        var isMissingContent =
          duration > 15 &&
          maxTsFound < duration - 10 &&
          srtText.indexOf("[") === -1;

        if ((hasBrokenLine || tsLines === 0 || isMissingContent) && !isRetry) {
          Monitor.warn(
            "Incomplete/Broken SRT for chunk " +
            chunkNum +
            " (End: " +
            maxTsFound +
            "s / Target: " +
            duration +
            "s) - Retrying...",
          );
          var strictPrompt =
            prompt +
            "\nCRITICAL: YOU STOPPED EARLY OR SKIPPED CONTENT. YOU MUST TRANSCRIBE THE ENTIRE " +
            Math.ceil(duration) +
            " SECONDS. USE [silence] IF NEEDED. NO BROKEN LINES.";
          return requestTranscription(
            key,
            url,
            fileId,
            strictPrompt,
            function (errR, textR) {
              if (errR) {
                activeCount--;
                launchNextChunk();
                return handleFlowError(
                  "Transcription failed for chunk " +
                  chunkNum +
                  " retry: " +
                  errR.message,
                  duration,
                );
              }
              validateAndRecord(textR, true);
            },
            600000,
            duration,
          );
        }

        recordChunkResult(idx, srtText, offset);
      }

      requestTranscription(
        key,
        url,
        fileId,
        prompt,
        function (errTr, text) {
          if (errTr) {
            Monitor.error(
              "Transcription Error - Retrying chunk " + chunkNum,
              errTr,
            );
            return requestTranscription(
              key,
              url,
              fileId,
              prompt,
              function (errTr2, text2) {
                if (errTr2) {
                  activeCount--;
                  launchNextChunk();
                  return handleFlowError(
                    "Transcription failed for chunk " +
                    chunkNum +
                    ": " +
                    errTr2.message,
                    duration,
                  );
                }
                validateAndRecord(text2, false);
              },
              600000,
              duration,
            );
          }
          validateAndRecord(text, false);
        },
        600000,
        duration,
      );
    }

    function recordChunkResult(idx, text, offset) {
      var chunkNum = idx + 1;
      if (!text || text.trim().length < 3) {
        Monitor.log("Empty/silent chunk at offset " + offset + "s — skipping");
        allSegments[idx] = "";
      } else {
        var clean = text
          .replace(/```[a-z]*\n?/gi, "")
          .replace(/```/g, "")
          .trim();
        var offsetted = offsetSrt(clean, offset, totalDuration);
        allSegments[idx] = offsetted;

        var sample = offsetted.match(
          /(\d{2}:\d{2}:\d{2},\d{3}) --> (\d{2}:\d{2}:\d{2},\d{3})/,
        );
        Monitor.log("Chunk Result Received", {
          chunk: chunkNum,
          offset: offset,
          firstTs: sample ? sample[0] : "none",
        });
      }

      completedCount++;
      activeCount--;

      // Chunks move from 0 to 100% within the 20-95% Global Stage
      var chunkProgress = (completedCount / totalChunks) * 100;
      updateProgress(chunkProgress, "Transcribed " + completedCount + " / " + totalChunks + " segments...");

      if (completedCount >= totalChunks) {
        finalizeChunkedFlow();
      } else {
        launchNextChunk(); // Keep the queue full
      }
    }

    function finalizeChunkedFlow() {
      if (window.qwintLog) {
        window.qwintLog("info", "merge_started", { segments: totalChunks });
      }
      const mergeStart = performance.now();
      // ── STEP 3: Finishing Stage (95-100%) ──
      setProgressStage(95, 100);
      updateProgress(0, "Merging all " + totalChunks + " segments...");
      const finalSrt = mergeSrtSegments(allSegments);
      if (window.qwintLog) {
        window.qwintLog("info", "merge_completed", { duration_ms: performance.now() - mergeStart });
        window.qwintLog("info", "merge_time", { duration_ms: performance.now() - mergeStart });
      }
      finishAndImport(finalSrt);
    }

    function finishAndImport(finalSrtContent) {
      // STEP: Normalize formatting, clamp timestamps to totalDuration, and repair logical errors
      finalSrtContent = normalizeSrtText(finalSrtContent, totalDuration);

      // Validate the merged SRT before import
      var srtLines = finalSrtContent.split("\n");
      var timestamps =
        finalSrtContent.match(
          /(\d{2}:\d{2}:\d{2},\d{3}) --> (\d{2}:\d{2}:\d{2},\d{3})/g,
        ) || [];
      Monitor.log("SRT Validation", {
        totalLines: srtLines.length,
        totalCaptions: timestamps.length,
        firstTimestamp: timestamps[0] || "NONE",
        lastTimestamp: timestamps[timestamps.length - 1] || "NONE",
      });

      if (timestamps.length === 0) {
        return handleFlowError(
          "Generated SRT is empty — no captions were produced.",
        );
      }

      var srtName = "qwint_final_" + Date.now() + ".srt";
      var srtPath = OUTPUT_DIR + "/" + srtName;
      if (window.qwintLog) {
        window.qwintLog("info", "subtitle_generation_completed", { duration_ms: performance.now() - subtitleStart });
        window.qwintLog("info", "import_started", {});
      }
      const importStart = performance.now();
      window.cep.fs.writeFile(
        toNativePath(srtPath),
        "\uFEFF" + finalSrtContent,
      );

      updateProgress(50, "Clearing sequence work area...");
      // Clear In/Out points so the full (not trimmed) sequence receives all captions
      cs.evalScript("qwint_clearInOutPoints()", function () {
        updateProgress(80, "Importing captions to Timeline...");
        cs.evalScript(
          'qwint_importSubtitles("' + srtPath.replace(/\\/g, "/") + '")',
          function (resImp) {
            if (window.qwintLog) {
              window.qwintLog("info", "import_completed", { duration_ms: performance.now() - importStart });
              window.qwintLog("info", "total_flow_time", { duration_ms: performance.now() - flowStart });
            }
            if (isCancelled) return;
            if (!parseResult(resImp).ok)
              return handleFlowError(
                "Final import failed: " + parseResult(resImp).message,
              );
            CreditManager.syncFromAPI();
            updateProgress(
              100,
              "Done! " + timestamps.length + " captions generated.",
            );
            isProcessing = false;
            setUIState("completed");
            Monitor.log("MASTER FLOW SUCCESSFUL", {
              totalChunks: totalChunks,
              totalCaptions: timestamps.length,
            });

            if (isTrimmed) {
              if (idleSubtitle) idleSubtitle.textContent = totalDuration + " seconds of video generated successfully as per your available credits.";
            }

            if (typeof logActivity === "function") {
              logActivity(
                "Long Video Flow Successful (" +
                sequenceName +
                ", " +
                timestamps.length +
                " captions)",
                true,
                totalDuration,
              );
            }
          },
        );
      });
    }

    function mergeSrtSegments(segments) {
      var merged = "";
      var counter = 1;
      for (var i = 0; i < segments.length; i++) {
        var seg = segments[i].trim();
        if (!seg) continue;
        merged += seg + "\n\n";
      }
      var lines = merged.split(/\r?\n/);
      var result = [];
      for (var l = 0; l < lines.length; l++) {
        var line = lines[l].trim();
        if (/^\d+$/.test(line)) {
          result.push(counter.toString());
          counter++;
        } else if (line !== "") {
          result.push(line);
        } else if (result.length > 0 && result[result.length - 1] !== "") {
          result.push("");
        }
      }
      return result.join("\n");
    }
  }

  // Fallback: single-pass for when Node.js WAV splitting is not available
  function startSinglePassTranscription(
    key,
    url,
    audioPath,
    totalDuration,
    sequenceName,
  ) {
    updateProgress(30, "Uploading full audio...");
    uploadAudioStreaming(key, url, audioPath, function (errUp, fileId) {
      if (errUp) return handleFlowError("Upload failed: " + errUp.message);
      updateProgress(60, "Transcribing (this may take several minutes)...");
      requestSrtFromProxy(
        key,
        url,
        fileId,
        function (errTr, srtText) {
          if (errTr) return handleFlowError(errTr.message);
          var srtName = "subtitles_" + Date.now() + ".srt";
          var srtPath = OUTPUT_DIR + "/" + srtName;
          window.cep.fs.writeFile(
            toNativePath(srtPath),
            "\uFEFF" + normalizeSrtText(srtText, totalDuration),
          );
          updateProgress(95, "Importing...");
          cs.evalScript(
            'qwint_importSubtitles("' + srtPath.replace(/\\/g, "/") + '")',
            function (resImp) {
              if (!parseResult(resImp).ok)
                return handleFlowError("Import failed.");
              CreditManager.syncFromAPI();
              updateProgress(100, "Done!");
              isProcessing = false;
              setUIState("completed");
            },
          );
        },
        1200000,
        totalDuration,
      );
    });
  }

  function uploadAudioStreaming(key, baseUrl, filePath, cb, attempt, isParallel) {
    attempt = attempt || 1;
    isParallel = !!isParallel;
    var maxRetries = 1; // Only 1 retry to avoid silent infinite loops
    var nativePath = toNativePath(filePath);
    var startTime = Date.now(); // Track upload duration

    Monitor.log("Upload Starting (Attempt " + attempt + ")", {
      path: nativePath,
      mem: Monitor.getMemory(),
    });

    // Check if Node is available for real streaming
    var hasNode = typeof require !== "undefined";
    if (!hasNode) {
      Monitor.log("Node.js not detected, using XHR fallback");
      return verifyAndReadAudioFile(filePath, function (err, bytes) {
        if (err) return cb(err);
        uploadAudioToProxy(key, baseUrl, "audio/wav", bytes, cb);
      });
    }

    try {
      var fs = require("fs");
      var https = require("https");
      var path = require("path");

      if (!fs.existsSync(nativePath)) {
        var err = new Error("Source file missing");
        Monitor.error("File Check Failed", err);
        return cb(err);
      }

      var stats = fs.statSync(nativePath);
      var fileSize = stats.size;
      Monitor.log("File Found", {
        sizeMB: (fileSize / 1024 / 1024).toFixed(2),
      });

      if (fileSize > 200 * 1024 * 1024) {
        Monitor.log("WARNING: Large file detected (>200MB)");
      }

      var targetUrl;
      try {
        targetUrl = new URL(baseUrl);
      } catch (e) {
        // ES5 Fallback for URL parsing if needed
        var parts = baseUrl.split("://");
        var protocol = parts[0] + ":";
        var rest = parts[1].split("/");
        var host = rest[0];
        var hostname = host.split(":")[0];
        var port = host.split(":")[1] || (protocol === "https:" ? 443 : 80);
        var pathname = "/" + rest.slice(1).join("/");
        targetUrl = {
          protocol: protocol,
          hostname: hostname,
          port: port,
          pathname: pathname,
        };
      }

      var apiEndpoint =
        PROXY_FILES_PATH +
        "?provider=" +
        encodeURIComponent(PROXY_FILES_PROVIDER);
      if (PROXY_FILES_TARGET_MODEL)
        apiEndpoint +=
          "&target_model_names=" + encodeURIComponent(PROXY_FILES_TARGET_MODEL);

      Monitor.log("Metadata Sync", {
        provider: PROXY_FILES_PROVIDER,
        target: PROXY_FILES_TARGET_MODEL,
        endpoint: baseUrl + apiEndpoint,
      });

      var boundary =
        "----QwintBoundary" + Math.random().toString(36).substring(2);

      // Validation: Hard size check
      var maxSizeBytes = API_MAX_FILE_SIZE_MB * 1024 * 1024;
      if (fileSize > maxSizeBytes) {
        Monitor.log("FATAL: File exceeds API limit", {
          current: (fileSize / 1024 / 1024).toFixed(2) + "MB",
          limit: API_MAX_FILE_SIZE_MB + "MB",
        });
        return cb(
          new Error(
            "Audio file is too large (" +
            (fileSize / 1024 / 1024).toFixed(1) +
            "MB). Maximum allowed is " +
            API_MAX_FILE_SIZE_MB +
            "MB. Use a shorter sequence or lower quality.",
          ),
        );
      }

      // 422 Prevention: Proper multipart parts
      var parts = [];
      parts.push(
        "--" +
        boundary +
        '\r\nContent-Disposition: form-data; name="purpose"\r\n\r\nuser_data\r\n',
      );
      if (PROXY_FILES_TARGET_MODEL) {
        parts.push(
          "--" +
          boundary +
          '\r\nContent-Disposition: form-data; name="target_model_names"\r\n\r\n' +
          PROXY_FILES_TARGET_MODEL +
          "\r\n",
        );
      }
      parts.push(
        "--" +
        boundary +
        '\r\nContent-Disposition: form-data; name="file"; filename="' +
        path.basename(nativePath) +
        '"\r\nContent-Type: audio/wav\r\n\r\n',
      );

      var header = parts.join("");
      var footer = "\r\n--" + boundary + "--\r\n";

      var options = {
        method: "POST",
        hostname: targetUrl.hostname,
        port: targetUrl.port,
        path: targetUrl.pathname.replace(/\/$/, "") + apiEndpoint,
        headers: {
          "Content-Type": "multipart/form-data; boundary=" + boundary,
          "Content-Length": header.length + fileSize + footer.length,
          "x-litellm-api-key": key,
          Authorization: "Bearer " + key,
        },
        timeout: 900000, // 15 minutes
      };

      Monitor.log("Request Configured", {
        host: options.hostname,
        path: options.path,
        timeout: options.timeout,
      });

      // Local tracker for this request to avoid jitter
      var lastLocalP = 0;

      var req = https.request(options, function (res) {
        Monitor.log("Response Received", {
          status: res.statusCode,
          headers: res.headers,
        });
        var chunks = [];
        res.on("data", function (d) {
          chunks.push(d);
        });
        res.on("end", function () {
          var body = Buffer.concat(chunks).toString("utf8");
          var duration = ((Date.now() - startTime) / 1000).toFixed(1);
          Monitor.log("Server Finished Request", {
            status: res.statusCode,
            bodyLength: body.length,
          });

          if (res.statusCode >= 200 && res.statusCode < 300) {
            try {
              // Robust parsing: trim and remove potential BOM
              var cleanBody = body.replace(/^\uFEFF/, "").trim();
              if (!cleanBody) throw new Error("Empty response body");

              var resp = JSON.parse(cleanBody);
              var id = resp.id || (resp.file && resp.file.id);
              if (!id) throw new Error("No file ID in response object");

              Monitor.log("Upload Successful", {
                id: id,
                time: duration + "s",
              });
              cb(null, id);
            } catch (e) {
              Monitor.error("Upload Response Parse Error: " + e.message, body);
              cb(new Error("Invalid response from server: " + e.message));
            }
          } else if (res.statusCode === 422) {
            Monitor.error("VALIDATION FAILURE (422)", body);
            var serverMsg = body;
            try {
              var errObj = JSON.parse(body);
              serverMsg =
                errObj.error ||
                errObj.message ||
                (errObj.detail ? JSON.stringify(errObj.detail) : body);
            } catch (e) { }
            // Permanent stop on 422 - format/validation issue
            cb(new Error("Server Validation Error (422): " + serverMsg));
          } else if (res.statusCode >= 500 && attempt <= maxRetries) {
            Monitor.log("Retrying after server error...");
            setTimeout(function () {
              uploadAudioStreaming(key, baseUrl, filePath, cb, attempt + 1);
            }, 3000);
          } else {
            Monitor.error("Upload Failed", {
              status: res.statusCode,
              body: body,
            });
            cb(new Error("Upload failed (HTTP " + res.statusCode + ")"));
          }
        });
      });

      req.on("error", function (e) {
        Monitor.error("Socket Error", e);
        if (attempt <= maxRetries && !isCancelled) {
          Monitor.log("Retrying after socket error...");
          setTimeout(function () {
            uploadAudioStreaming(key, baseUrl, filePath, cb, attempt + 1);
          }, 3000);
        } else {
          cb(e);
        }
      });

      req.on("timeout", function () {
        Monitor.error("Request Timeout Triggered");
        req.destroy();
        if (attempt <= maxRetries && !isCancelled) {
          Monitor.log("Retrying after timeout...");
          uploadAudioStreaming(key, baseUrl, filePath, cb, attempt + 1);
        } else {
          cb(new Error("Connection timed out during upload."));
        }
      });

      req.write(header);
      var fileStream = fs.createReadStream(nativePath);

      // Fine-grained progress
      var uploaded = 0;
      fileStream.on("data", function (chunk) {
        uploaded += chunk.length;
        var localP = Math.floor((uploaded / fileSize) * 100);
        // Only update if we are in single-pass mode (not parallel chunks)
        if (localP > lastLocalP) {
          lastLocalP = localP;
          updateProgress(localP);
        }
        if (progressMessage) {
          var mb = (uploaded / 1024 / 1024).toFixed(1);
          var totalMb = (fileSize / 1024 / 1024).toFixed(1);
          progressMessage.textContent =
            "Uploading: " + mb + "MB / " + totalMb + "MB";
        }
      });

      fileStream.pipe(req, { end: false });
      fileStream.on("end", function () {
        Monitor.log("File Stream Completed");
        req.end(footer);
      });
    } catch (e) {
      Monitor.error("Upload Logic Exception", e);
      // Failsafe fallback to XHR
      verifyAndReadAudioFile(filePath, function (err, bytes) {
        if (err) return cb(err);
        uploadAudioToProxy(key, baseUrl, "audio/wav", bytes, cb);
      });
    }
  }

  // --- Robust File I/O (RESTORED EXACTLY) ---

  function verifyAndReadAudioFile(path, callback, attempt) {
    attempt = attempt || 1;
    var native = toNativePath(path);
    try {
      if (typeof require !== "undefined") {
        var fs = require("fs");
        if (fs && fs.existsSync(native)) {
          var buffer = fs.readFileSync(native);
          if (buffer && buffer.length > 0)
            return callback(null, new Uint8Array(buffer));
        }
      }
    } catch (e) { }

    var result = window.cep.fs.readFile(normalizePath(path), "binary");
    if (result.err !== 0) {
      if (attempt < 3)
        return setTimeout(function () {
          verifyAndReadAudioFile(path, callback, attempt + 1);
        }, 1000);
      return callback(new Error("Read Failed (Code: " + result.err + ")"));
    }
    var data = result.data || "";
    var bytes = new Uint8Array(data.length);
    for (var i = 0; i < data.length; i++) bytes[i] = data.charCodeAt(i) & 0xff;
    callback(null, bytes);
  }

  function uploadAudioToProxy(key, url, mime, bytes, cb, attempt) {
    attempt = attempt || 1;
    var maxRetries = 1;
    var fullUrl =
      url +
      PROXY_FILES_PATH +
      "?provider=" +
      encodeURIComponent(PROXY_FILES_PROVIDER);

    Monitor.log("XHR Upload (Attempt " + attempt + ")", {
      url: fullUrl,
      sizeMB: (bytes.length / 1024 / 1024).toFixed(2),
    });

    var form = new FormData();
    form.append("file", new Blob([bytes], { type: mime }), "audio.wav");
    form.append("purpose", "user_data");
    if (PROXY_FILES_TARGET_MODEL)
      form.append("target_model_names", PROXY_FILES_TARGET_MODEL);

    var xhr = new XMLHttpRequest();
    xhr.open("POST", fullUrl, true);
    xhr.timeout = 600000; // 10 minutes
    xhr.setRequestHeader(PROXY_KEY_HEADER, key);
    xhr.setRequestHeader("Authorization", "Bearer " + key);

    xhr.upload.onprogress = function (e) {
      if (e.lengthComputable) {
        var localP = Math.floor((e.loaded / e.total) * 100);
        updateProgress(localP);
        if (progressMessage)
          progressMessage.textContent =
            "Upload Progress: " + Math.round((e.loaded / e.total) * 100) + "%";
      }
    };

    xhr.onload = function () {
      Monitor.log("XHR Status", { code: xhr.status });
      if (xhr.status >= 200 && xhr.status < 300) {
        try {
          var resp = JSON.parse(xhr.responseText);
          var id = resp.id || (resp.file && resp.file.id);
          Monitor.log("XHR Success", { id: id });
          cb(null, id);
        } catch (e) {
          cb(new Error("Parse Error"));
        }
      } else if (xhr.status === 422) {
        Monitor.error("XHR VALIDATION FAILURE (422)", xhr.responseText);
        cb(new Error("Server rejected audio format (422)."));
      } else if (xhr.status >= 500 && attempt <= maxRetries) {
        Monitor.log("XHR 500. Retrying...");
        setTimeout(function () {
          uploadAudioToProxy(key, url, mime, bytes, cb, attempt + 1);
        }, 2000);
      } else {
        Monitor.error("XHR Failure", xhr.responseText);
        cb(new Error("Upload Failed: " + xhr.status));
      }
    };
    xhr.ontimeout = function () {
      Monitor.error("XHR Timeout");
      if (attempt <= maxRetries) {
        uploadAudioToProxy(key, url, mime, bytes, cb, attempt + 1);
      } else {
        cb(new Error("Upload Timeout"));
      }
    };
    xhr.onerror = function () {
      Monitor.error("XHR Network Error");
      if (attempt <= maxRetries) {
        setTimeout(function () {
          uploadAudioToProxy(key, url, mime, bytes, cb, attempt + 1);
        }, 2000);
      } else {
        cb(new Error("Network Error"));
      }
    };
    xhr.send(form);
  }

  function requestTranscription(
    key,
    url,
    fileId,
    promptText,
    cb,
    customTimeout,
    duration,
  ) {
    var body = {
      model: PROXY_MODEL_NAME,
      temperature: 0,
      top_p: 0.1,
      max_tokens: 8192,
      user: key,
      metadata: {
        budget_required: (duration || (typeof currentDuration !== 'undefined' ? currentDuration : 0)) ? Math.floor(duration || currentDuration) : 0,
        app_id: APP_ID || "app_1",
      },
      messages: [
        {
          role: "user",
          content: [
            { type: "text", text: promptText },
            { type: "file", file: { file_id: fileId } },
          ],
        },
      ],
    };
    var xhr = new XMLHttpRequest();
    xhr.open("POST", url + PROXY_CHAT_PATH, true);
    xhr.timeout = customTimeout || 300000;
    xhr.setRequestHeader("Content-Type", "application/json");
    xhr.setRequestHeader(PROXY_KEY_HEADER, key);
    xhr.setRequestHeader("Authorization", "Bearer " + key);
    xhr.onload = function () {
      Monitor.log("Transcription Step Finished", { status: xhr.status });
      if (xhr.status >= 200 && xhr.status < 300) {
        try {
          var cleanText = xhr.responseText.replace(/^\uFEFF/, "").trim();
          if (!cleanText) throw new Error("Empty response body");

          var resp = JSON.parse(cleanText);
          var choice = resp.choices && resp.choices[0] ? resp.choices[0] : null;
          var content =
            choice && choice.message ? choice.message.content : null;

          if (!content) {
            if (choice && choice.finish_reason === "length")
              throw new Error(
                "Chunk too long for AI limit (Tokens: " +
                resp.usage.total_tokens +
                ")",
              );
            throw new Error("Empty response from AI");
          }
          cb(null, content);
        } catch (e) {
          Monitor.error(
            "Transcription Step Parse Error: " + e.message,
            xhr.responseText,
          );
          cb(new Error("Transcription failed: " + e.message));
        }
      } else {
        Monitor.error("Transcription Step Server Error", xhr.responseText);
        cb(new Error("Transcription Failed: " + xhr.status));
      }
    };
    xhr.ontimeout = function () {
      Monitor.error("Transcription Step Timeout");
      cb(new Error("Transcription Timeout"));
    };
    xhr.onerror = function () {
      Monitor.error("Transcription Step Network Error");
      cb(new Error("Network Error during transcription"));
    };
    xhr.send(JSON.stringify(body));
  }

  function requestMasterSrtFormatting(key, url, fullTranscript, cb) {
    var masterPrompt =
      "You are a professional subtitle formatting engine.\n\nYou are given a FULL merged transcript of a long video.\nThe transcript already contains accurate timestamps.\n\nYour task:\n\nConvert the entire transcript into perfectly formatted SRT captions.\n\nSTRICT RULES:\n\n1. Do NOT rewrite or summarize.\n2. Do NOT remove any words.\n3. Do NOT improve grammar.\n4. Do NOT interpret.\n5. Preserve 100% verbatim accuracy.\n6. Maintain exact timestamp continuity.\n7. Do not overlap captions.\n8. Do not leave timing gaps.\n9. Output ONLY valid SRT format.\n10. No markdown.\n11. No explanations.\n12. No commentary.\n\nCAPTION RULES:\n\n- Maximum 2 lines per caption.\n- Maximum 42 characters per line.\n- Break lines naturally.\n- Do NOT break words.\n- Keep speech flow natural.\n\nTIMESTAMP RULES:\n\n- Format strictly as HH:MM:SS,mmm\n- Ensure chronological order.\n- Ensure no time overlaps.\n- Ensure no missing segments.\n\nIf transcript contains silence gaps,\npreserve natural timing but do not fabricate speech.\n\nIf transcript section is empty,\nskip it without generating empty captions.\n\nIf output exceeds token limit, stop cleanly at last complete caption block.\n\nNow process the following full transcript:\n\n" +
      fullTranscript;

    var body = {
      model: PROXY_MODEL_NAME,
      temperature: 0,
      top_p: 0.1,
      max_tokens: 8192,
      user: key,
      metadata: {
        wallet_value: userCreditSeconds,
      },
      messages: [{ role: "user", content: masterPrompt }],
    };

    var xhr = new XMLHttpRequest();
    xhr.open("POST", url + PROXY_CHAT_PATH, true);
    xhr.timeout = 600000; // 10 minutes for master formatting
    xhr.setRequestHeader("Content-Type", "application/json");
    xhr.setRequestHeader(PROXY_KEY_HEADER, key);
    xhr.setRequestHeader("Authorization", "Bearer " + key);
    xhr.onload = function () {
      if (xhr.status >= 200 && xhr.status < 300) {
        try {
          var cleanFormat = xhr.responseText.replace(/^\uFEFF/, "").trim();
          if (!cleanFormat) throw new Error("Empty response body");

          var resp = JSON.parse(cleanFormat);
          var content =
            resp.choices && resp.choices[0] && resp.choices[0].message
              ? resp.choices[0].message.content
              : null;
          if (!content) throw new Error("No content in master format response");

          cb(
            null,
            content
              .replace(/```[a-z]*\n?/gi, "")
              .replace(/```/g, "")
              .trim(),
          );
        } catch (e) {
          Monitor.error(
            "Master format parse error: " + e.message,
            xhr.responseText,
          );
          cb(new Error("Master format parse error: " + e.message));
        }
      } else {
        cb(new Error("Master format failed: " + xhr.status));
      }
    };
    xhr.onerror = function () {
      cb(new Error("Network error during master formatting"));
    };
    xhr.send(JSON.stringify(body));
  }

  function requestSrtFromProxy(key, url, fileId, cb, customTimeout, duration) {
    requestTranscription(
      key,
      url,
      fileId,
      "Transcribe the audio and return ONLY valid SRT text.",
      cb,
      customTimeout,
      duration,
    );
  }

  // --- Subtitle Continuity Repair ---
  // After format normalization, fix LOGICAL timestamp errors:
  //   1) AI gives absurd end times: 01:03:00 when next subtitle starts at 00:04:20
  //   2) AI drops minute prefix: writes 00:00:43 when it meant 00:06:43
  //   3) AI timestamps go backwards then resume normally
  function repairSrtContinuity(text) {
    var lines = text.split("\n");
    var tsPattern = /^(\d{2}:\d{2}:\d{2},\d{3}) --> (\d{2}:\d{2}:\d{2},\d{3})$/;

    // Step 1: Parse all entries into structured data
    var entries = [];
    for (var i = 0; i < lines.length; i++) {
      var match = lines[i].match(tsPattern);
      if (match) {
        entries.push({
          lineIdx: i,
          startSec: parseSrtTime(match[1]),
          endSec: parseSrtTime(match[2]),
        });
      }
    }

    if (entries.length < 2) return text;

    // Step 2: Basic Durations and Forward Jumps
    //   - No single caption should be > 15 seconds (AI hallucination/logic error)
    //   - No gap should be > 60 seconds (educational content doesn't have 1-min silences)
    for (var m = 0; m < entries.length; m++) {
      var cur = entries[m];
      var nxt = entries[m + 1];

      // Fix absurd duration (>15s)
      if (cur.endSec - cur.startSec > 15) {
        cur.endSec = cur.startSec + 5; // Reset to reasonable 5s
        lines[cur.lineIdx] =
          formatSrtTime(cur.startSec) + " --> " + formatSrtTime(cur.endSec);
      }

      if (nxt) {
        // Fix absurd forward gaps (>60s)
        // If the gap is massive, the AI likely hallucinated the minutes/hours
        if (nxt.startSec > cur.endSec + 60) {
          var gap = 0.5; // Small human gap
          var originalDuration = nxt.endSec - nxt.startSec;
          if (originalDuration <= 0) originalDuration = 3;

          nxt.startSec = cur.endSec + gap;
          nxt.endSec = nxt.startSec + originalDuration;
          lines[nxt.lineIdx] =
            formatSrtTime(nxt.startSec) + " --> " + formatSrtTime(nxt.endSec);
        }
      }
    }

    // Step 3: Fix backward-jumping starts (AI dropped minute/hour prefix)
    // If a start is way before the previous end, the AI likely dropped the minute
    for (var j = 1; j < entries.length; j++) {
      var prev = entries[j - 1];
      var curr = entries[j];

      // Find next "normal" entry (one that's in sequence after prev)
      var nextNormal = null;
      for (var k = j + 1; k < entries.length && k <= j + 10; k++) {
        if (entries[k].startSec > prev.endSec - 5) {
          nextNormal = entries[k];
          break;
        }
      }

      // Check if current start jumped backward significantly
      if (curr.startSec < prev.endSec - 0.5) {
        var prevEnd = prev.endSec;
        var bestStart = curr.startSec;
        var bestEnd = curr.endSec;
        var duration = curr.endSec - curr.startSec;
        if (duration <= 0) duration = 3;

        // Calculate expected minute from previous entry
        var expectedMin = Math.floor(prevEnd / 60);

        // Try the expected minute as offset
        var candidateStart = expectedMin * 60 + (curr.startSec % 60);
        if (candidateStart < prevEnd - 0.1) {
          candidateStart = (expectedMin + 1) * 60 + (curr.startSec % 60);
        }

        // Only apply if the candidate makes logical sense
        if (
          candidateStart >= prevEnd - 0.1 &&
          (!nextNormal || candidateStart < nextNormal.startSec + 5)
        ) {
          var offset = candidateStart - curr.startSec;
          bestStart = candidateStart;
          bestEnd = curr.endSec + offset;
          if (bestEnd <= bestStart) bestEnd = bestStart + duration;
        } else {
          // If minute-repair fails, just force it after prev
          bestStart = prevEnd + 0.1;
          bestEnd = bestStart + duration;
        }

        curr.startSec = bestStart;
        curr.endSec = bestEnd;
        lines[curr.lineIdx] =
          formatSrtTime(curr.startSec) + " --> " + formatSrtTime(curr.endSec);
      }
    }

    // Step 4: Final pass — fix any remaining end < start issues
    for (var n = 0; n < entries.length; n++) {
      if (entries[n].endSec <= entries[n].startSec) {
        entries[n].endSec = entries[n].startSec + 3;
        lines[entries[n].lineIdx] =
          formatSrtTime(entries[n].startSec) +
          " --> " +
          formatSrtTime(entries[n].endSec);
      }
    }

    return lines.join("\n");
  }

  // --- Subtitle Normalization ---
  function normalizeSrtText(raw, duration) {
    var text = raw
      .replace(/```[a-z]*\n?/gi, "")
      .replace(/```/g, "")
      .trim();
    // STEP 1: Normalize timestamp FORMAT (fix colons, missing hours, 2-digit ms, etc.)
    text = normalizeSrtTimestamps(text, duration);
    // STEP 2: Repair timestamp LOGIC (fix backward jumps, absurd end times)
    text = repairSrtContinuity(text);
    return "\uFEFF" + text;
  }

  // --- Settings & Init ---

  function getProxyKey() {
    return (
      (proxyKeyInput ? proxyKeyInput.value.trim() : "") ||
      localStorage.getItem(PROXY_KEY_STORAGE) ||
      ""
    );
  }
  function getProxyUrl() {
    var url =
      (proxyUrlInput ? proxyUrlInput.value.trim() : "") ||
      localStorage.getItem(PROXY_URL_STORAGE) ||
      DEFAULT_PROXY_URL;
    return url.replace(/\/+$/, "");
  }

  function getDashboardUrl() {
    var key = getProxyKey();
    var url = localStorage.getItem("qwint.dashboardUrl") || DASHBOARD_URL;
    if (url.indexOf("?") === -1) {
      return url + "?key=" + encodeURIComponent(key);
    } else {
      return url + "&key=" + encodeURIComponent(key);
    }
  }

  function saveProxySettings() {
    localStorage.setItem(PROXY_KEY_STORAGE, proxyKeyInput.value.trim());
    localStorage.setItem(PROXY_URL_STORAGE, proxyUrlInput.value.trim());
    appendLog("Settings saved.");
  }

  function setActiveView(view) {
    currentView = view;
    var workflow = document.getElementById("view-workflow");
    var settings = document.getElementById("view-settings");
    var btn = document.getElementById("btn-settings");

    workflow.classList.toggle("is-active", view === "workflow");
    settings.classList.toggle("is-active", view === "settings");
    btn.classList.toggle("is-active", view === "settings");
  }

  function showCreditModal(current, required) {
    if (!creditModal) return;
    modalMsg.innerHTML =
      "You have <b>" +
      CreditManager.formatTime(current) +
      "</b> remaining.<br>This sequence requires <b>" +
      CreditManager.formatTime(required) +
      "</b>.";
    creditModal.style.display = "flex";
  }

  function hideCreditModal() {
    if (creditModal) creditModal.style.display = "none";
  }

  // --- Connection Manager Module (Isolated) ---
  var ConnectionManager = {
    isOnline: function () {
      return navigator.onLine;
    },
    updateEngineIndicator: function () {
      var dot = document.querySelector(".engine-dot");
      var label = document.querySelector(".engine-label");
      if (!dot || !label) return;

      if (this.isOnline()) {
        dot.classList.remove("offline");
        dot.classList.add("success");
        label.classList.remove("offline");
        label.textContent = "READY";
      } else {
        dot.classList.remove("success");
        dot.classList.add("offline");
        label.classList.add("offline");
        label.textContent = "NO INTERNET";
      }
    },
    showOfflineModal: function () {
      var modal = document.getElementById("offline-modal");
      if (modal) modal.style.display = "flex";
    },
    hideOfflineModal: function () {
      var modal = document.getElementById("offline-modal");
      if (modal) modal.style.display = "none";
    },
    initListeners: function () {
      var self = this;
      window.addEventListener("online", function () {
        self.updateEngineIndicator();
      });
      window.addEventListener("offline", function () {
        self.updateEngineIndicator();
      });

      var btnRetry = document.getElementById("btn-offline-retry");
      var btnCancel = document.getElementById("btn-offline-cancel");

      if (btnRetry) {
        btnRetry.addEventListener("click", function () {
          if (self.isOnline()) {
            self.hideOfflineModal();
          }
        });
      }
      if (btnCancel) {
        btnCancel.addEventListener("click", function () {
          self.hideOfflineModal();
        });
      }

      this.updateEngineIndicator();
    },
  };

  function init() {
    const renderStart = performance.now();
    btnMainAction = document.getElementById("btn-main-action");
    statusPrimary = document.getElementById("status-primary");
    statusSecondary = document.getElementById("status-secondary");
    progressContainer = document.getElementById("progress-container");
    progressFill = document.getElementById("progress-fill");
    progressMessage = document.getElementById("progress-message");
    idleTitle = document.getElementById("idle-title");
    idleSubtitle = document.getElementById("idle-subtitle");
    proxyKeyInput = document.getElementById("api-key");
    proxyUrlInput = document.getElementById("proxy-url");
    logEl = document.getElementById("log");

    creditBadge = document.getElementById("credit-badge");
    creditModal = document.getElementById("credit-modal");
    modalMsg = document.getElementById("modal-msg");
    btnTopUp = document.getElementById("btn-topup");
    btnModalCancel = document.getElementById("btn-modal-cancel");
    btnToggleHistory = document.getElementById("btn-toggle-history");
    historyContainer = document.getElementById("history-container");
    historyList = document.getElementById("history-list");

    OUTPUT_DIR = computeOutputDir();

    // Wire Events
    btnMainAction.addEventListener("click", function () {
      if (!isProcessing && !ConnectionManager.isOnline()) {
        ConnectionManager.showOfflineModal();
        return;
      }
      startGenerateFlow();
    });
    document
      .getElementById("btn-settings")
      .addEventListener("click", function () {
        setActiveView(currentView === "settings" ? "workflow" : "settings");
      });
    document
      .getElementById("btn-save-key")
      .addEventListener("click", saveProxySettings);
    document
      .getElementById("btn-back-to-workflow")
      .addEventListener("click", function () {
        setActiveView("workflow");
      });
    document
      .getElementById("btn-reset-key")
      .addEventListener("click", function () {
        proxyKeyInput.value = "";
        localStorage.removeItem(PROXY_KEY_STORAGE);
      });
    document
      .getElementById("btn-open-folder")
      .addEventListener("click", function () {
        cs.evalScript("qwint_openOutputFolder()");
      });
    document
      .getElementById("btn-close-app")
      .addEventListener("click", function () {
        cs.closeExtension();
      });

    document
      .getElementById("btn-footer-topup")
      .addEventListener("click", function () {
        window.cep.util.openURLInDefaultBrowser(getDashboardUrl());
      });

    var menuDashboard = document.getElementById("menu-dashboard");
    if (menuDashboard) {
      menuDashboard.addEventListener("click", function () {
        window.cep.util.openURLInDefaultBrowser(getDashboardUrl());
        var profileDropdown = document.getElementById("profile-dropdown");
        if (profileDropdown) profileDropdown.style.display = "none";
      });
    }

    if (btnTopUp) {
      btnTopUp.addEventListener("click", function () {
        window.cep.util.openURLInDefaultBrowser(getDashboardUrl());
        hideCreditModal();
      });
    }
    if (btnModalCancel) {
      btnModalCancel.addEventListener("click", hideCreditModal);
    }

    if (btnToggleHistory) {
      btnToggleHistory.addEventListener("click", function () {
        var s = historyContainer.style.display === "none";
        historyContainer.style.display = s ? "block" : "none";
      });
    }

    // Load saved
    loadConfig();
    proxyKeyInput.value = localStorage.getItem(PROXY_KEY_STORAGE) || "";
    proxyUrlInput.value =
      localStorage.getItem(PROXY_URL_STORAGE) || DEFAULT_PROXY_URL;

    // Load JSX
    var extRoot = cs.getSystemPath(SystemPath.EXTENSION);
    var jsxPath = extRoot + "/QwintSubtitileCEP.jsx";
    cs.evalScript('$.evalFile("' + jsxPath.replace(/\\/g, "/") + '")');

    ConnectionManager.initListeners();
    CreditManager.updateUI();
    CreditManager.syncFromAPI();
    setUIState("idle");

    // Initialize New Logging Infrastructure
    if (window.QwintDB && window.QwintSync && window.QwintLogger) {
      window.QwintDB.initDB().then(function () {
        window.QwintSync.startLogSync();
        window.QwintLogger.log("INFO", "PLUGIN_LOADED", "Qwint Caption loaded", getLogMeta());
      }).catch(function (err) {
        console.error("DB Init Failed", err);
        if (window.QwintLogger) {
          window.QwintLogger.log("ERROR", "DB_INIT_FAILED", "IndexedDB initialization failed", { error: err });
        }
      });
    }

    // Sync credits from API every 30 seconds
    setInterval(function () {
      if (!isProcessing) {
        CreditManager.syncFromAPI();
      }
    }, 30000);

    const renderEnd = performance.now();
    if (window.qwintLog) {
      window.qwintLog("info", "panel_render_time", { duration_ms: renderEnd - renderStart });
    }
  }

  /**
   * Helper to collect all metadata for logs
   */
  function getLogMeta(extra) {
    var meta = {
      sequenceName: localStorage.getItem("qwint.lastSequenceName") || "unknown",
      projectName: localStorage.getItem("qwint.lastProjectName") || "unknown",
      duration: currentDuration,
      userId: APP_ID || "unknown",
      licenseKey: typeof getProxyKey === "function" ? getProxyKey() : "unknown",
      version: "1.0.0"
    };
    if (extra && typeof extra === 'object') {
      for (var k in extra) {
        if (extra.hasOwnProperty(k)) meta[k] = extra[k];
      }
    }
    return meta;
  }

  document.addEventListener("DOMContentLoaded", init);
})();

