#target premierepro
#targetengine "qwintsubtitilecep"

var QWINT = QWINT || {};
QWINT.OUTPUT_DIR = (function () {
  try {
    if (Folder.userData) {
      return Folder.userData.fsName + "/subtitle-generator";
    }
    if (Folder.temp) {
      return Folder.temp.fsName + "/subtitle-generator";
    }
  } catch (e) {
  }
  return "/tmp/subtitle-generator";
})();
QWINT.WAV_PRESET_PATH = "";
QWINT.SPEECH_PRESET_PATH = "";
QWINT.LAST_EXPORT_PATH = "";

function qwint_sep() {
  try {
    if ($.os && $.os.toLowerCase().indexOf("windows") >= 0) {
      return "\\";
    }
  } catch (e) {
  }
  return "/";
}

function qwint_joinPath(dir, file) {
  if (!dir || dir.length === 0) {
    return file;
  }
  if (!file || file.length === 0) {
    return dir;
  }
  var sep = qwint_sep();
  var d = dir;
  if (d.charAt(d.length - 1) !== "/" && d.charAt(d.length - 1) !== "\\") {
    d = d + sep;
  }
  var f = file;
  if (f.charAt(0) === "/" || f.charAt(0) === "\\") {
    f = f.substr(1);
  }
  return d + f;
}

(function initBundledPreset() {
  try {
    var root = File($.fileName).parent.fsName;
    var bundled = qwint_joinPath(qwint_joinPath(root, "payloads"), "wav_48k_16bit.epr");
    var f = new File(bundled);
    if (f.exists) {
      QWINT.WAV_PRESET_PATH = f.fsName;
    }
    var speechBundled = qwint_joinPath(qwint_joinPath(root, "payloads"), "speech_optimized.epr");
    var fs = new File(speechBundled);
    if (fs.exists) {
      QWINT.SPEECH_PRESET_PATH = fs.fsName;
    }
  } catch (e) {
  }
})();

function qwint_ping() {
  return qwint_ok("ExtendScript ready.");
}

function qwint_setOutputDir(path) {
  if (!path || path.length === 0) {
    return qwint_err("Output folder path is empty.");
  }
  QWINT.OUTPUT_DIR = path;
  var folder = qwint_ensureFolder(QWINT.OUTPUT_DIR);
  if (!folder) {
    return qwint_err("Failed to create output folder: " + QWINT.OUTPUT_DIR);
  }
  return qwint_ok("Output folder set.", folder.fsName);
}

function qwint_validateSequence() {
  var seq = qwint_getActiveSequence();
  if (!seq) {
    return qwint_err("No active sequence selection. Please open/select a sequence in the Timeline.");
  }
  return qwint_ok("Sequence validated: " + seq.name);
}

function qwint_getSequenceDurationSeconds() {
  var seq = qwint_getActiveSequence();
  if (!seq) {
    return qwint_err("No active sequence.");
  }

  // 1. Check for content across ALL video and audio tracks
  var hasContent = false;
  var v, a, i;
  var maxEnd = 0;

  for (v = 0; v < seq.videoTracks.numTracks; v++) {
    var vt = seq.videoTracks[v];
    if (vt.clips.numItems > 0) {
      hasContent = true;
      for (i = 0; i < vt.clips.numItems; i++) {
        if (vt.clips[i].end.seconds > maxEnd) maxEnd = vt.clips[i].end.seconds;
      }
    }
  }

  for (a = 0; a < seq.audioTracks.numTracks; a++) {
    var at = seq.audioTracks[a];
    if (at.clips.numItems > 0) {
      hasContent = true;
      for (i = 0; i < at.clips.numItems; i++) {
        if (at.clips[i].end.seconds > maxEnd) maxEnd = at.clips[i].end.seconds;
      }
    }
  }

  if (!hasContent) {
    return qwint_err("Timeline has no clips.");
  }

  // 2. Get sequence end time properly
  var seconds = 0;
  try {
    if (seq.end && typeof seq.end.seconds === "number" && seq.end.seconds > 0) {
      seconds = seq.end.seconds;
    } else {
      seconds = maxEnd;
    }
  } catch (e) {
    seconds = maxEnd;
  }

  if (seconds <= 0) {
    return qwint_err("Sequence has zero duration.");
  }

  return qwint_ok("Sequence duration confirmed", "", seconds.toString());
}

function qwint_exportAudio() {
  return qwint_performExport(false);
}

function qwint_exportAudioOptimized() {
  return qwint_performExport(true);
}

function qwint_performExport(isOptimized) {
  var seq = qwint_getActiveSequence();
  if (!seq) {
    return qwint_err("No active sequence found. Open a sequence and try again.");
  }

  var outDir = qwint_ensureFolder(QWINT.OUTPUT_DIR);
  if (!outDir) {
    return qwint_err("Failed to create output folder: " + QWINT.OUTPUT_DIR);
  }

  var suffix = isOptimized ? "_speech.wav" : ".wav";
  var outPath = qwint_joinPath(outDir.fsName, "sequence_audio_" + qwint_timestamp() + suffix);

  var presetPath = isOptimized ? QWINT.SPEECH_PRESET_PATH : QWINT.WAV_PRESET_PATH;
  if (!presetPath || !new File(presetPath).exists) {
    presetPath = qwint_getWavPresetPath();
  }

  if (!presetPath) {
    return qwint_err("Could not locate an export preset.");
  }

  try {
    var workArea = qwint_getWorkAreaConstant();
    var ok = false;

    if (typeof seq.exportAsMediaDirect === "function") {
      ok = seq.exportAsMediaDirect(outPath, presetPath, workArea);
      if (ok) {
        var f = new File(outPath);
        var tries = 0;
        while (!f.exists && tries < 10) {
          $.sleep(200);
          tries++;
        }
        if (!f.exists) {
          return qwint_err("Export reported success but file is missing: " + outPath);
        }
        QWINT.LAST_EXPORT_PATH = outPath;
        return qwint_ok("Exported audio.", outPath);
      }
    }

    if (app.encoder && typeof app.encoder.encodeSequence === "function") {
      app.encoder.launchEncoder();
      var jobId = app.encoder.encodeSequence(seq, outPath, presetPath, workArea, 1);
      if (jobId) {
        QWINT.LAST_EXPORT_PATH = outPath;
        return qwint_ok("Queued audio export in Media Encoder.", outPath, "Job ID: " + jobId);
      }
    }

    return qwint_err("Export failed. Check preset path and try again.");
  } catch (e) {
    // Failsafe: if optimized failed, try normal
    if (isOptimized) {
      return qwint_performExport(false);
    }
    return qwint_err("Export failed: " + e);
  }
}

function qwint_secsToTicks(secs) {
  // Premiere Pro internal tick rate: 254016000000 ticks per second
  return Math.round(secs * 254016000000);
}

function qwint_exportAudioSegmentOptimized(startTime, endTime) {
  return qwint_performSegmentExport(true, startTime, endTime);
}

function qwint_exportAudioSegment(startTime, endTime) {
  return qwint_performSegmentExport(false, startTime, endTime);
}

function qwint_performSegmentExport(isOptimized, startTime, endTime) {
  var seq = qwint_getActiveSequence();
  if (!seq) return qwint_err("No active sequence found.");

  var outDir = qwint_ensureFolder(QWINT.OUTPUT_DIR);
  if (!outDir) return qwint_err("Failed to create output folder.");

  var suffix = isOptimized ? "_speech.wav" : ".wav";
  var outPath = qwint_joinPath(outDir.fsName, "chunk_" + Math.floor(startTime) + "_" + qwint_timestamp() + suffix);

  var presetPath = isOptimized ? QWINT.SPEECH_PRESET_PATH : QWINT.WAV_PRESET_PATH;
  if (!presetPath || !new File(presetPath).exists) {
    presetPath = qwint_getWavPresetPath();
  }
  if (!presetPath) return qwint_err("Could not locate an export preset.");

  // Convert seconds to ticks for Premiere Pro API
  var startTicks = qwint_secsToTicks(startTime);
  var endTicks = qwint_secsToTicks(endTime);
  var expectedDuration = endTime - startTime;

  // Save existing in/out points so we can restore them
  var oldIn, oldOut;
  try { oldIn = seq.getInPoint(); } catch (e) { oldIn = 0; }
  try { oldOut = seq.getOutPoint(); } catch (e) { oldOut = 0; }

  try {
    // Set In/Out using ticks (correct Premiere API)
    seq.setInPoint(startTicks);
    seq.setOutPoint(endTicks);
    $.sleep(800); // Wait for Premiere to register the range change

    var ok = false;
    if (typeof seq.exportAsMediaDirect === "function") {
      // 2 = Export Work Area (In to Out)
      ok = seq.exportAsMediaDirect(outPath, presetPath, 2);
      if (ok) {
        var f = new File(outPath);
        var tries = 0;
        while (!f.exists && tries < 30) { $.sleep(300); tries++; }
        seq.setInPoint(oldIn);
        seq.setOutPoint(oldOut);

        if (!f.exists) return qwint_err("Export success but file missing.");

        // Validate: chunk should not be larger than full sequence audio
        // A 3-minute mono 16kHz wav = ~5.5MB max
        var fileSizeMB = f.length / 1024 / 1024;
        return qwint_ok("Exported segment.", outPath, fileSizeMB.toFixed(2) + "MB|" + startTime + "-" + endTime);
      }
    }

    seq.setInPoint(oldIn);
    seq.setOutPoint(oldOut);
    return qwint_err("Segment export returned false. exportAsMediaDirect not supported.");
  } catch (e) {
    try { seq.setInPoint(oldIn); seq.setOutPoint(oldOut); } catch (e2) { }
    return qwint_err("Export exception: " + e.toString());
  }
}

function qwint_generateSubtitles() {
  var seq = qwint_getActiveSequence();
  if (!seq) {
    return qwint_err("No active sequence found. Open a sequence and try again.");
  }

  var outDir = qwint_ensureFolder(QWINT.OUTPUT_DIR);
  if (!outDir) {
    return qwint_err("Failed to create output folder: " + QWINT.OUTPUT_DIR);
  }

  var srtPath = qwint_joinPath(outDir.fsName, "subtitles.srt");
  var srtText = qwint_buildMockSrt(10, 3);

  if (!qwint_writeFile(srtPath, srtText)) {
    return qwint_err("Failed to write SRT file: " + srtPath);
  }

  return qwint_importSubtitles(srtPath);
}

function qwint_clearInOutPoints() {
  try {
    var seq = qwint_getActiveSequence();
    if (!seq) return qwint_err("No active sequence.");
    // Clear work area so full timeline receives captions
    if (typeof seq.setInPoint === "function") {
      seq.setInPoint(0);
      seq.setOutPoint(seq.end.ticks || seq.end);
    }
    return qwint_ok("In/Out points cleared.");
  } catch (e) {
    return qwint_ok("Could not clear in/out points (non-fatal): " + e);
  }
}

function qwint_importSubtitles(srtPath) {
  var seq = qwint_getActiveSequence();
  if (!seq) return qwint_err("No active sequence found.");

  if (!srtPath || srtPath.length === 0) return qwint_err("SRT path is empty.");

  var srtFile = new File(srtPath);
  if (!srtFile.exists) return qwint_err("SRT file does not exist: " + srtPath);

  // ── Step 1: Import SRT into project ────────────────────────────
  var importOk = app.project.importFiles([srtFile.fsName], false, app.project.rootItem, false);
  if (!importOk) return qwint_err("Failed to import SRT into project.");

  var items = app.project.rootItem.findItemsMatchingMediaPath(srtFile.fsName, 1);
  if (!items || items.length === 0) return qwint_err("Imported SRT not found in project.");

  var captionItem = items[0];

  // ── Step 2: Get sequence end time (in ticks) ────────────────────
  var seqEndTicks = 0;
  try {
    seqEndTicks = seq.end; // This is a TickTime object in newer Premiere
    if (typeof seqEndTicks === "object" && seqEndTicks.ticks) {
      seqEndTicks = seqEndTicks.ticks;
    }
  } catch (e) { seqEndTicks = 0; }

  // ── Step 3: Create caption track ────────────────────────────────
  var created = false;
  try {
    if (typeof seq.createCaptionTrack === "function") {
      // Place at tick 0, no format arg (let Premiere decide from SRT content)
      created = seq.createCaptionTrack(captionItem, 0);
    }
  } catch (e2) {
    return qwint_err("Caption track creation failed: " + e2);
  }

  if (!created) {
    // Fallback: open the SRT folder so user can import manually
    srtFile.parent.execute();
    return qwint_err("createCaptionTrack() failed. SRT folder opened — drag the file to your timeline manually. File: " + srtFile.name);
  }

  // ── Step 4: Extend placed caption clip to full sequence length ──
  // createCaptionTrack sometimes clips at the item's default duration.
  // We need to find and extend the clip on the new caption track.
  try {
    $.sleep(500); // Wait for Premiere to register the track
    var numTracks = seq.captionTracks.numTracks;
    if (numTracks > 0) {
      var captionTrack = seq.captionTracks[numTracks - 1]; // Last added track
      if (captionTrack && captionTrack.clips.numItems > 0) {
        var captionClip = captionTrack.clips[0];
        // Extend end point to match sequence end
        if (seqEndTicks && seqEndTicks > 0) {
          try { captionClip.end = seqEndTicks; } catch (ext) { }
        }
        // Also try setting outPoint on the clip item
        try { captionClip.outPoint = captionItem.getOutPoint(); } catch (op) { }
      }
    }
  } catch (e3) {
    // Non-fatal: extension failed but captions still exist
  }

  return qwint_ok("Imported SRT and created captions.", srtPath);
}


function qwint_openOutputFolder() {
  var outDir = qwint_ensureFolder(QWINT.OUTPUT_DIR);
  if (!outDir) {
    return qwint_err("Output folder is missing and could not be created.");
  }

  var opened = outDir.execute();
  if (!opened) {
    return qwint_err("Could not open output folder in Finder.");
  }

  return qwint_ok("Opened output folder.", outDir.fsName);
}

function qwint_getAudioTracks() {
  var seq = qwint_getActiveSequence();
  if (!seq) return '{"ok":"false","message":"No active sequence."}';
  var tracks = [];
  var num = seq.audioTracks.numTracks;
  for (var i = 0; i < num; i++) {
    var tr = seq.audioTracks[i];
    if (tr.clips.numItems > 0) {
      var trackName = tr.name || ("Audio " + (i + 1));
      // Clean name of characters that break JSON
      trackName = trackName.replace(/[\\"]/g, "");
      tracks.push('{\\"index\\":' + i + ',\\"name\\":\\"' + trackName + '\\"}');
    }
  }
  return '{"ok":"true","message":"Tracks fetched","path":"","details":"[' + tracks.join(",") + ']"}';
}

function qwint_setSoloTrack(index) {
  var seq = qwint_getActiveSequence();
  if (!seq) return qwint_err("No active sequence.");

  index = parseInt(index);
  var num = seq.audioTracks.numTracks;

  for (var i = 0; i < num; i++) {
    var tr = seq.audioTracks[i];
    if (i === index) {
      tr.solo = true;
      tr.mute = false;
    } else {
      tr.solo = false;
      tr.mute = true;
    }
  }
  return qwint_ok("Track " + (index + 1) + " soloed.");
}

function qwint_getTrackBounds(index) {
  var seq = qwint_getActiveSequence();
  if (!seq) return qwint_err("No active sequence.");
  if (index < 0 || index >= seq.audioTracks.numTracks) return qwint_err("Invalid track index.");

  var tr = seq.audioTracks[index];
  if (tr.clips.numItems === 0) return qwint_err("Track has no clips.");

  var start = tr.clips[0].start.seconds;
  var end = tr.clips[0].end.seconds;

  for (var i = 1; i < tr.clips.numItems; i++) {
    var clip = tr.clips[i];
    if (clip.start.seconds < start) start = clip.start.seconds;
    if (clip.end.seconds > end) end = clip.end.seconds;
  }

  var duration = end - start;
  // Use single escaping for JSON nested inside a JSON string
  var details = '{\\"start\\":' + start + ',\\"end\\":' + end + ',\\"duration\\":' + duration + '}';
  return '{"ok":"true","message":"Track bounds fetched","path":"","details":"' + details + '"}';
}

function qwint_getActiveSequence() {
  if (!app || !app.project) {
    return null;
  }
  return app.project.activeSequence;
}

function qwint_ensureFolder(path) {
  var folder = new Folder(path);
  if (!folder.exists) {
    try {
      folder.create();
    } catch (e) {
      return null;
    }
  }
  return folder;
}

function qwint_writeFile(path, contents) {
  var file = new File(path);
  file.encoding = "UTF-8";
  if (!file.open("w")) {
    return false;
  }
  file.write(contents);
  file.close();
  return true;
}

function qwint_buildMockSrt(count, secondsPerLine) {
  var lines = [];
  var start = 0;
  for (var i = 0; i < count; i++) {
    var end = start + secondsPerLine;
    lines.push((i + 1).toString());
    lines.push(qwint_formatTime(start) + " --> " + qwint_formatTime(end));
    lines.push("Mock subtitle line " + (i + 1));
    lines.push("");
    start = end;
  }
  return lines.join("\n");
}

function qwint_formatTime(totalSeconds) {
  var ms = Math.floor((totalSeconds % 1) * 1000);
  var secs = Math.floor(totalSeconds);
  var s = secs % 60;
  var m = Math.floor(secs / 60) % 60;
  var h = Math.floor(secs / 3600);
  return qwint_pad2(h) + ":" + qwint_pad2(m) + ":" + qwint_pad2(s) + "," + qwint_pad3(ms);
}

function qwint_pad2(num) {
  return (num < 10 ? "0" : "") + num;
}

function qwint_pad3(num) {
  if (num < 10) {
    return "00" + num;
  }
  if (num < 100) {
    return "0" + num;
  }
  return "" + num;
}

function qwint_timestamp() {
  var d = new Date();
  var y = d.getFullYear();
  var m = qwint_pad2(d.getMonth() + 1);
  var day = qwint_pad2(d.getDate());
  var h = qwint_pad2(d.getHours());
  var min = qwint_pad2(d.getMinutes());
  var s = qwint_pad2(d.getSeconds());
  return "" + y + m + day + "_" + h + min + s;
}

function qwint_getWavPresetPath() {
  if (QWINT.WAV_PRESET_PATH && QWINT.WAV_PRESET_PATH.length > 0) {
    return QWINT.WAV_PRESET_PATH;
  }

  if (app.encoder && typeof app.encoder.getPresetPathByName === "function") {
    var names = [
      "WAV - 48kHz - 16bit Stereo",
      "WAV - 48kHz - 16-bit Stereo",
      "Waveform Audio",
      "WAV"
    ];

    for (var i = 0; i < names.length; i++) {
      try {
        var preset = app.encoder.getPresetPathByName(names[i]);
        if (preset && preset.length > 0) {
          return preset;
        }
      } catch (e) {
      }
    }
  }

  var roots = [
    Folder("~/Documents/Adobe/Adobe Media Encoder"),
    Folder("~/Library/Application Support/Adobe/Adobe Media Encoder")
  ];

  for (var r = 0; r < roots.length; r++) {
    var found = qwint_findPresetRecursive(roots[r], /wav/i, 3);
    if (found) {
      return found;
    }
  }

  return "";
}

function qwint_findPresetRecursive(folder, nameRegex, depth) {
  if (!folder || !folder.exists || depth < 0) {
    return "";
  }

  var entries = folder.getFiles();
  for (var i = 0; i < entries.length; i++) {
    var entry = entries[i];
    if (entry instanceof Folder) {
      var nested = qwint_findPresetRecursive(entry, nameRegex, depth - 1);
      if (nested) {
        return nested;
      }
    } else if (entry instanceof File) {
      var lower = entry.name.toLowerCase();
      if (lower.indexOf(".epr") !== -1 && nameRegex.test(entry.name)) {
        return entry.fsName;
      }
    }
  }

  return "";
}

function qwint_getWorkAreaConstant() {
  if (app.encoder && app.encoder.ENCODE_ENTIRE !== undefined) {
    return app.encoder.ENCODE_ENTIRE;
  }
  return 1;
}

function qwint_ok(message, path, details) {
  return qwint_stringify({
    ok: true,
    message: message || "OK",
    path: path || "",
    details: details || ""
  });
}

function qwint_err(message) {
  return qwint_stringify({
    ok: false,
    message: message || "Error"
  });
}

function qwint_stringify(obj) {
  if (typeof JSON !== "undefined" && JSON && typeof JSON.stringify === "function") {
    return JSON.stringify(obj);
  }
  var parts = [];
  for (var key in obj) {
    if (!obj.hasOwnProperty(key)) {
      continue;
    }
    var val = obj[key];
    if (val === null || val === undefined) {
      val = "";
    }
    parts.push('\"' + key + '\":\"' + val.toString().replace(/\"/g, '\\\\\"') + '\"');
  }
  return '{' + parts.join(',') + '}';
}
