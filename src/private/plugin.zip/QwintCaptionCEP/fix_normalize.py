import re

filepath = r'C:\Users\karan\AppData\Roaming\Adobe\CEP\extensions\QwintSubtitileCEP\js\panel.js'

with open(filepath, 'r', encoding='utf-8') as f:
    content = f.read()

old = """  // Normalize ALL timestamp variants (MM:SS,mmm AND HH:MM:SS,mmm) to HH:MM:SS,mmm
  function normalizeSrtTimestamps(text) {
    // Matches: optional HH: + MM:SS,mmm --> optional HH: + MM:SS,mmm
    return text.replace(
      /((?:\\d{1,2}:)?\\d{1,2}:\\d{2},\\d{3})\\s*-->\\s*((?:\\d{1,2}:)?\\d{1,2}:\\d{2},\\d{3})/g,
      function (m, s, e) {
        return formatSrtTime(parseSrtTime(s)) + ' --> ' + formatSrtTime(parseSrtTime(e));
      }
    );
  }"""

new = """  // Normalize ALL broken AI timestamp formats to standard HH:MM:SS,mmm --> HH:MM:SS,mmm
  function normalizeSrtTimestamps(text) {
    var lines = text.split('\\n');
    var out = [];
    for (var i = 0; i < lines.length; i++) {
      var line = lines[i];
      // Fix 1: colon-as-comma e.g. "02:38:100" -> "02:38,100"
      line = line.replace(/(\\d{1,2}):(\\d{2}):(\\d{3})(?=\\s|,|$|-)/g, function(m, a, b, c) {
        return parseInt(c) > 59 ? a + ':' + b + ',' + c : m;
      });
      // Fix 2: missing --> e.g. "02:38,100,02:42,600" -> "02:38,100 --> 02:42,600"
      line = line.replace(/^(\\d{1,2}:\\d{2},\\d{3}),(\\d{1,2}:\\d{2},\\d{3})\\s*$/, '$1 --> $2');
      // Fix 3: standardize all timestamp pairs to HH:MM:SS,mmm
      line = line.replace(/((?:\\d{1,2}:)?(?:\\d{1,2}:)?\\d{1,2},\\d{3})\\s*-->\\s*((?:\\d{1,2}:)?(?:\\d{1,2}:)?\\d{1,2},\\d{3})/g,
        function(m, s, e) {
          return formatSrtTime(parseSrtTime(s)) + ' --> ' + formatSrtTime(parseSrtTime(e));
        }
      );
      out.push(line);
    }
    return out.join('\\n');
  }"""

if old in content:
    content = content.replace(old, new, 1)
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(content)
    print("SUCCESS: normalizeSrtTimestamps replaced.")
else:
    print("ERROR: Old function text not found. Printing context around line 415...")
    lines = content.split('\n')
    for i, line in enumerate(lines[412:430], start=413):
        print(f"{i}: {repr(line)}")
