(function () {
  'use strict';

  var cs = new CSInterface();
  var logEl;
  var proxyKeyInput;
  var proxyUrlInput;
  var PROXY_MODEL_NAME = 'gemini/gemini-2.5-flash';
  var PROXY_FILES_PROVIDER = 'gemini/gemini-2.5-flash';
  var PROXY_FILES_TARGET_MODEL = 'gemini/gemini-2.5-flash';
  var PROXY_FILES_TARGET_STORAGE = 'default';
  var PROXY_FILES_CUSTOM_PROVIDER = '';
  var PROXY_FILES_METADATA = '';
  var PROXY_FILES_PATH = '/files';
  var PROXY_CHAT_PATH = '/v1/chat/completions';
  var PROXY_KEY_STORAGE = 'qwint.proxyKey';
  var PROXY_URL_STORAGE = 'qwint.proxyBaseUrl';
  var PROXY_KEY_HEADER = 'x-litellm-api-key';
  var DEFAULT_PROXY_URL = 'https://dev.llm-plugin.qwintsoft.com';
  var CONFIG_SEEDED_STORAGE = 'qwint.configSeeded'; // flag: config.json already applied
  var lastAudioPath = '';
  var currentView = 'workflow';
  var generateBtn;
  var stepExportEl;
  var stepGenerateEl;
  var stepDoneEl;
  var isProcessing = false;
  var IS_WINDOWS = (function () {
    try {
      var info = cs.getOSInformation();
      return info && info.indexOf('Windows') >= 0;
    } catch (e) {
      return false;
    }
  })();
  var OUTPUT_DIR = computeOutputDir();

  function isInvalidPath(path) {
    if (!path || path.length === 0) {
      return true;
    }
    if (path === 'invalidParam' || path.indexOf('invalid') === 0) {
      return true;
    }
    if (IS_WINDOWS) {
      if (/^[A-Za-z]:[\\/]/.test(path) || /^\\\\/.test(path)) {
        return false;
      }
      return true;
    }
    if (path[0] !== '/') {
      return true;
    }
    return false;
  }

  function normalizeBase(path) {
    if (!path) {
      return '';
    }
    return path.replace(/[\\/]+$/, '');
  }

  function pickBasePath() {
    var base = cs.getSystemPath(SystemPath.USER_DATA);
    if (isInvalidPath(base)) {
      base = cs.getSystemPath(SystemPath.TEMP);
    }
    if (isInvalidPath(base)) {
      base = cs.getSystemPath(SystemPath.MY_DOCUMENTS);
    }
    if (isInvalidPath(base)) {
      base = '/tmp';
    }
    base = normalizeBase(base);
    if (!base || base.length === 0) {
      base = '/tmp';
    }
    return base;
  }

  function computeOutputDir() {
    var base = pickBasePath();
    return joinPath(base, 'subtitle-generator');
  }

  function nowStamp() {
    var d = new Date();
    return d.toLocaleTimeString();
  }

  function appendLog(message, level) {
    if (!logEl) {
      return;
    }
    var line = '[' + nowStamp() + '] ' + message + '\n';
    if (level === 'error') {
      line = '[' + nowStamp() + '] ERROR: ' + message + '\n';
    }
    logEl.textContent += line;
    logEl.scrollTop = logEl.scrollHeight;
  }

  function normalizeFsPath(path) {
    if (!path) {
      return path;
    }
    return path.replace(/\\/g, '/');
  }

  function toNativePath(path) {
    if (!path) {
      return path;
    }
    if (IS_WINDOWS) {
      return path.replace(/\//g, '\\');
    }
    return path.replace(/\\/g, '/');
  }

  function safePath(path) {
    return path.replace(/\\/g, '/').replace(/'/g, "\\'");
  }

  function joinPath(dir, file) {
    if (!dir) {
      return file;
    }
    var cleanDir = dir.replace(/[\\/]+$/, '').replace(/\\/g, '/');
    return cleanDir + '/' + file;
  }

  function loadJSX() {
    var extRoot = cs.getSystemPath(SystemPath.EXTENSION);
    var jsxPath = safePath(extRoot + '/QwintSubtitileCEP.jsx');

    appendLog('Loading JSX: ' + jsxPath);
    cs.evalScript('$.evalFile("' + jsxPath + '")', function () {
      cs.evalScript('qwint_ping()', function (pingResult) {
        handleResult('Ping', pingResult);
      });

      cs.evalScript('qwint_setOutputDir("' + safePath(OUTPUT_DIR) + '")', function (res) {
        handleResult('Output Dir', res);
        try {
          var parsed = JSON.parse(res);
          if (parsed && parsed.ok && parsed.path) {
            OUTPUT_DIR = normalizeFsPath(parsed.path);
            appendLog('Output dir (native): ' + OUTPUT_DIR);
          }
        } catch (e) {
        }
      });
    });
  }

  function handleResult(label, result) {
    if (!result) {
      appendLog(label + ' returned no response.', 'error');
      return;
    }

    var parsed;
    try {
      parsed = JSON.parse(result);
    } catch (err) {
      appendLog(label + ': ' + result);
      return;
    }

    if (parsed.ok) {
      appendLog(label + ': ' + (parsed.message || 'OK'));
    } else {
      appendLog(label + ': ' + (parsed.message || 'Failed'), 'error');
    }

    if (parsed.path) {
      appendLog('Path: ' + parsed.path);
    }

    if (label === 'Export Audio' && parsed.path) {
      lastAudioPath = normalizeFsPath(parsed.path);
      appendLog('Last audio set: ' + lastAudioPath);
    }

    if (parsed.details) {
      appendLog(parsed.details);
    }
  }

  function parseResult(result) {
    if (!result) {
      return null;
    }
    try {
      return JSON.parse(result);
    } catch (e) {
      return null;
    }
  }

  function isOkResult(result) {
    var parsed = parseResult(result);
    return parsed && parsed.ok;
  }

  function runAction(label, script, done) {
    appendLog('Running: ' + label + '...');
    cs.evalScript(script, function (result) {
      handleResult(label, result);
      if (typeof done === 'function') {
        done(result);
      }
    });
  }

  function setActiveView(viewName) {
    var workflowView = document.getElementById('view-workflow');
    var settingsView = document.getElementById('view-settings');
    var settingsBtn = document.getElementById('btn-settings');
    var showSettings = viewName === 'settings';

    currentView = showSettings ? 'settings' : 'workflow';

    if (workflowView) {
      workflowView.hidden = showSettings;
      workflowView.classList.toggle('is-active', !showSettings);
    }

    if (settingsView) {
      settingsView.hidden = !showSettings;
      settingsView.classList.toggle('is-active', showSettings);
    }

    if (settingsBtn) {
      settingsBtn.classList.toggle('is-active', showSettings);
      settingsBtn.setAttribute('aria-pressed', showSettings ? 'true' : 'false');
    }
  }

  function wireSettingsToggle() {
    var settingsBtn = document.getElementById('btn-settings');
    if (settingsBtn) {
      settingsBtn.addEventListener('click', function () {
        setActiveView(currentView === 'settings' ? 'workflow' : 'settings');
      });
    }

    setActiveView('workflow');
  }

  function setStepState(el, state) {
    if (!el) {
      return;
    }
    el.classList.remove('is-active', 'is-done', 'is-error');
    if (state === 'active') {
      el.classList.add('is-active');
    } else if (state === 'done') {
      el.classList.add('is-done');
    } else if (state === 'error') {
      el.classList.add('is-error');
    }
  }

  function resetProcessSteps() {
    setStepState(stepExportEl, 'idle');
    setStepState(stepGenerateEl, 'idle');
    setStepState(stepDoneEl, 'idle');
  }

  function setProcessing(active) {
    isProcessing = active;
    if (generateBtn) {
      generateBtn.disabled = active;
      generateBtn.classList.toggle('is-disabled', active);
    }
  }

  function startGenerateFlow() {
    if (isProcessing) {
      return;
    }
    resetProcessSteps();
    setProcessing(true);
    setStepState(stepExportEl, 'active');

    runAction('Export Audio', 'qwint_exportAudio()', function (result) {
      if (!isOkResult(result)) {
        setStepState(stepExportEl, 'error');
        setProcessing(false);
        return;
      }

      setStepState(stepExportEl, 'done');
      setStepState(stepGenerateEl, 'active');

      generateSubtitlesProxy(function (ok) {
        if (ok) {
          setStepState(stepGenerateEl, 'done');
          setStepState(stepDoneEl, 'done');
        } else {
          setStepState(stepGenerateEl, 'error');
        }
        setProcessing(false);
      });
    });
  }

  function ensureOutputDir() {
    if (isInvalidPath(OUTPUT_DIR)) {
      return false;
    }
    var fsDir = toNativePath(OUTPUT_DIR);
    try {
      var stat = window.cep.fs.stat(fsDir);
      if (stat.err === 0 && stat.data && stat.data.isDirectory()) {
        return true;
      }
      var created = window.cep.fs.createDirectory(fsDir);
      return created.err === 0;
    } catch (e) {
      return false;
    }
  }

  function formatTime(totalSeconds) {
    var ms = Math.floor((totalSeconds % 1) * 1000);
    var secs = Math.floor(totalSeconds);
    var s = secs % 60;
    var m = Math.floor(secs / 60) % 60;
    var h = Math.floor(secs / 3600);
    return pad2(h) + ':' + pad2(m) + ':' + pad2(s) + ',' + pad3(ms);
  }

  function pad2(num) {
    return (num < 10 ? '0' : '') + num;
  }

  function pad3(num) {
    if (num < 10) {
      return '00' + num;
    }
    if (num < 100) {
      return '0' + num;
    }
    return '' + num;
  }

  function makeTimestamp() {
    var d = new Date();
    var y = d.getFullYear();
    var m = pad2(d.getMonth() + 1);
    var day = pad2(d.getDate());
    var h = pad2(d.getHours());
    var min = pad2(d.getMinutes());
    var s = pad2(d.getSeconds());
    return '' + y + m + day + '_' + h + min + s;
  }

  function findLatestWavPath() {
    try {
      var listing = window.cep.fs.readdir(toNativePath(OUTPUT_DIR));
      if (listing.err !== 0 || !listing.data || !listing.data.length) {
        return '';
      }
      var files = listing.data.filter(function (name) {
        return name.toLowerCase().indexOf('.wav') !== -1;
      });
      if (!files.length) {
        return '';
      }
      files.sort();
      var latestName = files[files.length - 1];
      return joinPath(OUTPUT_DIR, latestName);
    } catch (e) {
      return '';
    }
  }

  function stripFences(text) {
    if (!text) {
      return text;
    }
    return text.replace(/```[a-z]*\n?/gi, '').replace(/```/g, '').trim();
  }

  function parseTimestampLine(line) {
    var match = line.match(/(\d{1,2}:\d{2}:\d{2}[,\.]\d{1,3}|\d{1,2}:\d{2}[\.,:]\d{1,3})\s*-->\s*(\d{1,2}:\d{2}:\d{2}[,\.]\d{1,3}|\d{1,2}:\d{2}[\.,:]\d{1,3})/);
    if (!match) {
      return null;
    }
    return { start: match[1], end: match[2], raw: match[0] };
  }

  function parseTimeToSeconds(raw) {
    if (!raw) {
      return 0;
    }
    var cleaned = raw.trim();
    if (cleaned.indexOf(',') !== -1 || cleaned.indexOf('.') !== -1) {
      cleaned = cleaned.replace('.', ',');
      var parts = cleaned.split(':');
      var h = 0;
      var m = 0;
      var sMs = '0,000';
      if (parts.length === 2) {
        m = parseInt(parts[0], 10) || 0;
        sMs = parts[1];
      } else if (parts.length >= 3) {
        h = parseInt(parts[0], 10) || 0;
        m = parseInt(parts[1], 10) || 0;
        sMs = parts[2];
      }
      var secParts = sMs.split(',');
      var s = parseInt(secParts[0], 10) || 0;
      var ms = parseInt(secParts[1], 10) || 0;
      return h * 3600 + m * 60 + s + (ms / 1000);
    }
    if (/^\d{1,2}:\d{2}:\d{1,3}$/.test(cleaned)) {
      var bits = cleaned.split(':');
      var mm = parseInt(bits[0], 10) || 0;
      var ss = parseInt(bits[1], 10) || 0;
      var ms2 = parseInt(bits[2], 10) || 0;
      return mm * 60 + ss + (ms2 / 1000);
    }
    if (/^\d{1,2}:\d{2}$/.test(cleaned)) {
      var parts2 = cleaned.split(':');
      return (parseInt(parts2[0], 10) || 0) * 60 + (parseInt(parts2[1], 10) || 0);
    }
    return 0;
  }

  function secondsToTimestamp(sec) {
    if (!sec || sec < 0) {
      sec = 0;
    }
    var h = Math.floor(sec / 3600);
    var m = Math.floor((sec % 3600) / 60);
    var s = Math.floor(sec % 60);
    var ms = Math.floor((sec % 1) * 1000);
    return pad2(h) + ':' + pad2(m) + ':' + pad2(s) + ',' + pad3(ms);
  }

  function normalizeTimestamp(t) {
    return secondsToTimestamp(parseTimeToSeconds(t));
  }

  function timeToSeconds(t) {
    return parseTimeToSeconds(t);
  }

  function tryParseSrtBlocks(raw) {
    var text = stripFences(raw || '');
    text = text.replace(/\r\n/g, '\n').trim();
    if (!text) {
      return null;
    }
    var blocks = text.split(/\n{2,}/);
    var cues = [];
    for (var i = 0; i < blocks.length; i++) {
      var block = blocks[i].trim();
      if (!block) {
        continue;
      }
      var timestampCount = (block.match(/-->/g) || []).length;
      if (timestampCount > 1) {
        continue;
      }
      var lines = block.split('\n').map(function (l) { return l.trim(); }).filter(Boolean);
      if (!lines.length) {
        continue;
      }
      var idx = 0;
      if (/^\d+$/.test(lines[0])) {
        idx = 1;
      }
      if (!lines[idx]) {
        continue;
      }
      var stamp = parseTimestampLine(lines[idx]);
      if (!stamp) {
        continue;
      }
      var textLines = lines.slice(idx + 1).filter(function (l) {
        return !parseTimestampLine(l);
      });
      cues.push({
        start: stamp.start,
        end: stamp.end,
        text: textLines.length ? textLines : ['...']
      });
    }
    return cues.length ? cues : null;
  }

  function parseTimestampedLines(raw) {
    var text = stripFences(raw || '');
    text = text.replace(/\r\n/g, '\n').trim();
    if (!text) {
      return { cues: [], found: false };
    }
    var lines = text.split('\n');
    var cues = [];
    var current = null;
    var found = false;
    for (var i = 0; i < lines.length; i++) {
      var line = lines[i].trim();
      if (!line) {
        continue;
      }
      var stamp = parseTimestampLine(line);
      if (stamp) {
        found = true;
        if (current) {
          if (!current.text.length) {
            current.text.push('...');
          }
          cues.push(current);
        }
        var remainder = line.replace(stamp.raw, '').trim();
        current = {
          start: stamp.start,
          end: stamp.end,
          text: remainder ? [remainder] : []
        };
        continue;
      }
      if (current) {
        current.text.push(line);
      }
    }
    if (current) {
      if (!current.text.length) {
        current.text.push('...');
      }
      cues.push(current);
    }
    return { cues: cues, found: found };
  }

  function buildSrtFromCues(cues, durationSeconds) {
    var lines = [];
    var lastEnd = 0;
    var minStart = null;
    var maxEnd = 0;
    for (var t = 0; t < cues.length; t++) {
      var st = timeToSeconds(cues[t].start);
      if (minStart === null || st < minStart) {
        minStart = st;
      }
      var en = timeToSeconds(cues[t].end);
      if (en > maxEnd) {
        maxEnd = en;
      }
    }
    if (minStart === null) {
      minStart = 0;
    }
    var scale = 1;
    if (durationSeconds && durationSeconds > 1 && maxEnd > 0) {
      var shiftedMax = Math.max(0, maxEnd - minStart);
      if (shiftedMax > durationSeconds * 1.2) {
        scale = durationSeconds / shiftedMax;
      }
    }
    for (var i = 0; i < cues.length; i++) {
      var cue = cues[i];
      var startSec = (timeToSeconds(cue.start) - minStart) * scale;
      var endSec = (timeToSeconds(cue.end) - minStart) * scale;
      if (startSec < 0) {
        startSec = 0;
      }
      if (endSec < 0) {
        endSec = 0;
      }
      var start = secondsToTimestamp(startSec);
      var end = secondsToTimestamp(endSec);
      if (endSec <= startSec) {
        endSec = startSec + 2;
        end = secondsToTimestamp(endSec);
      }
      if (startSec < lastEnd) {
        startSec = lastEnd;
        endSec = Math.max(startSec + 2, endSec);
        start = secondsToTimestamp(startSec);
        end = secondsToTimestamp(endSec);
      }
      lastEnd = endSec;
      lines.push(String(i + 1));
      lines.push(start + ' --> ' + end);
      if (cue.text && cue.text.length) {
        for (var j = 0; j < cue.text.length; j++) {
          lines.push(cue.text[j]);
        }
      } else {
        lines.push('...');
      }
      lines.push('');
    }
    return lines.join('\n');
  }

  function normalizeSrtText(raw, durationSeconds) {
    var parsed = tryParseSrtBlocks(raw);
    if (parsed && parsed.length) {
      var srtParsed = buildSrtFromCues(parsed, durationSeconds);
      srtParsed = srtParsed.replace(/\r?\n/g, '\r\n');
      return '\uFEFF' + srtParsed;
    }

    var inlineParsed = parseTimestampedLines(raw);
    if (inlineParsed.found && inlineParsed.cues.length) {
      var srtInline = buildSrtFromCues(inlineParsed.cues, durationSeconds);
      srtInline = srtInline.replace(/\r?\n/g, '\r\n');
      return '\uFEFF' + srtInline;
    }

    var text = stripFences(raw || '');
    text = text.replace(/\r\n/g, '\n').trim();
    var lines = text.split('\n');
    var cleaned = [];
    var timePattern = /(\d{1,2}:\d{2}:\d{2}[,\.:\d]{0,4})\s*-->\s*(\d{1,2}:\d{2}:\d{2}[,\.:\d]{0,4})/;

    for (var i = 0; i < lines.length; i++) {
      var line = lines[i].trim();
      if (!line) {
        continue;
      }
      if (/^\d+$/.test(line)) {
        continue;
      }
      var match = line.match(timePattern);
      if (match) {
        var remainder = line.replace(timePattern, '').trim();
        if (remainder) {
          cleaned.push(remainder);
        }
        continue;
      }
      cleaned.push(line);
    }

    var joined = cleaned.join(' ').replace(/\s+/g, ' ').trim();
    if (!joined) {
      joined = 'Subtitle generation completed.';
    }

    var sentences = joined.split(/[.!?]\s+/);
    var segments = sentences.filter(function (s) { return s && s.trim(); });

    if (segments.length > 12) {
      var combined = [];
      var groupSize = Math.ceil(segments.length / 12);
      for (var g = 0; g < segments.length; g += groupSize) {
        combined.push(segments.slice(g, g + groupSize).join(' '));
      }
      segments = combined;
    }

    if (segments.length < 3) {
      var words = joined.split(/\s+/);
      var chunkSize = Math.max(4, Math.ceil(words.length / 6));
      var chunks = [];
      for (var w = 0; w < words.length; w += chunkSize) {
        chunks.push(words.slice(w, w + chunkSize).join(' '));
      }
      segments = chunks.length ? chunks : segments;
    }

    var cues = [];
    var cursor = 0;
    var total = (typeof durationSeconds === 'number' && durationSeconds > 1) ? durationSeconds : 0;
    var baseDuration = total && segments.length ? Math.max(2, total / segments.length) : 3;
    for (var s = 0; s < segments.length; s++) {
      var seg = segments[s].trim();
      if (!seg) {
        continue;
      }
      var duration = Math.min(6, Math.max(2.5, baseDuration));
      var start = cursor;
      var end = cursor + duration;
      cues.push({
        start: formatTime(start),
        end: formatTime(end),
        text: [seg]
      });
      cursor = end;
    }

    if (!cues.length) {
      cues.push({ start: formatTime(0), end: formatTime(3), text: ['Subtitle generation completed.'] });
    }

    var linesOut = [];
    for (var c = 0; c < cues.length; c++) {
      linesOut.push(String(c + 1));
      linesOut.push(cues[c].start + ' --> ' + cues[c].end);
      linesOut.push(cues[c].text[0]);
      linesOut.push('');
    }

    var srt = linesOut.join('\n').replace(/\r?\n/g, '\r\n');
    return '\uFEFF' + srt;
  }

  /**
   * Reads the bundled config.json from the extension root.
   * If the key has never been seeded (CONFIG_SEEDED_STORAGE not set),
   * it writes the values from config.json into localStorage and marks the
   * flag so the file is never consulted again.
   * Calls `done()` when finished (whether or not seeding was needed).
   */
  function loadConfigFile(done) {
    // Already seeded on a previous launch — skip file read entirely
    if (localStorage.getItem(CONFIG_SEEDED_STORAGE)) {
      appendLog('Config already seeded from file. Using stored settings.');
      if (typeof done === 'function') { done(); }
      return;
    }

    var extRoot = cs.getSystemPath(SystemPath.EXTENSION);
    if (!extRoot) {
      appendLog('Could not resolve extension root. Skipping config seed.', 'error');
      if (typeof done === 'function') { done(); }
      return;
    }

    var configPath = safePath(extRoot) + '/config.json';
    appendLog('First launch — reading config from: ' + configPath);

    // Helper: apply a parsed config object to localStorage
    function applyConfig(cfg) {
      var seeded = false;
      if (cfg && cfg.proxyKey && cfg.proxyKey !== 'REPLACE_WITH_CUSTOMER_API_KEY') {
        localStorage.setItem(PROXY_KEY_STORAGE, cfg.proxyKey);
        appendLog('API key seeded from config.json into local storage.');
        seeded = true;
      }
      if (cfg && cfg.proxyBaseUrl) {
        localStorage.setItem(PROXY_URL_STORAGE, cfg.proxyBaseUrl);
        appendLog('Proxy URL seeded from config.json into local storage.');
        seeded = true;
      }
      if (seeded) {
        localStorage.setItem(CONFIG_SEEDED_STORAGE, '1');
        appendLog('Config seeding complete. File will not be read again.');
      } else {
        appendLog('config.json found but key is placeholder — skipping seed.');
      }
      if (typeof done === 'function') { done(); }
    }

    // Try CEP FS first (synchronous, always available)
    try {
      var nativePath = toNativePath(extRoot + '/config.json');
      var res = window.cep.fs.readFile(nativePath, 'utf8');
      if (res && res.err === 0 && res.data) {
        var cfg = JSON.parse(res.data);
        applyConfig(cfg);
        return;
      }
    } catch (e) {
      appendLog('CEP FS config read error: ' + e.message, 'error');
    }

    // Fallback: Node.js fs (async)
    readFileWithNode(toNativePath(extRoot + '/config.json'), function (err, bytes) {
      if (!err && bytes) {
        try {
          var text = String.fromCharCode.apply(null, bytes);
          var cfg2 = JSON.parse(text);
          applyConfig(cfg2);
          return;
        } catch (e2) {
          appendLog('Node config parse error: ' + e2.message, 'error');
        }
      }
      appendLog('config.json not readable — continuing without seed.', 'error');
      if (typeof done === 'function') { done(); }
    });
  }

  function loadSavedSettings() {
    var key = localStorage.getItem(PROXY_KEY_STORAGE);
    if (key && proxyKeyInput) {
      proxyKeyInput.value = key;
      appendLog('Proxy access key loaded from local storage.');
    }
    var url = normalizeProxyUrl(localStorage.getItem(PROXY_URL_STORAGE) || '');
    if (!url) {
      url = DEFAULT_PROXY_URL;
    }
    if (url && proxyUrlInput) {
      proxyUrlInput.value = url;
      appendLog('Proxy base URL loaded from local storage.');
    }
  }

  function saveProxySettings() {
    var url = proxyUrlInput ? normalizeProxyUrl(proxyUrlInput.value.trim()) : '';
    var key = proxyKeyInput ? proxyKeyInput.value.trim() : '';
    if (!url) {
      appendLog('Proxy base URL is empty. Enter it before saving.', 'error');
      return;
    }
    if (!key) {
      appendLog('Proxy access key is empty. Paste a key before saving.', 'error');
      return;
    }
    localStorage.setItem(PROXY_URL_STORAGE, url);
    localStorage.setItem(PROXY_KEY_STORAGE, key);
    appendLog('Proxy settings saved locally.');
  }

  function resetProxyKey() {
    localStorage.removeItem(PROXY_KEY_STORAGE);
    if (proxyKeyInput) {
      proxyKeyInput.value = '';
    }
    appendLog('Proxy access key cleared.');
  }

  function getProxyKey() {
    var key = proxyKeyInput ? proxyKeyInput.value.trim() : '';
    if (key) {
      return key;
    }
    key = localStorage.getItem(PROXY_KEY_STORAGE);
    return key || '';
  }

  function getProxyUrl() {
    var url = proxyUrlInput ? proxyUrlInput.value.trim() : '';
    if (url) {
      return normalizeProxyUrl(url);
    }
    url = localStorage.getItem(PROXY_URL_STORAGE);
    url = normalizeProxyUrl(url || '');
    return url || DEFAULT_PROXY_URL;
  }

  function readFileBinary(path) {
    var res = window.cep.fs.readFile(path, 'binary');
    if (res.err !== 0) {
      return { ok: false, err: res.err };
    }
    var data = res.data || '';
    var bytes = new Uint8Array(data.length);
    for (var i = 0; i < data.length; i++) {
      bytes[i] = data.charCodeAt(i) & 0xff;
    }
    return { ok: true, bytes: bytes };
  }

  function readFileBase64(path) {
    var res = window.cep.fs.readFile(path, 'base64');
    if (res.err === 0 && res.data) {
      return { ok: true, base64: res.data };
    }
    return { ok: false, err: res.err };
  }

  function base64ToBytes(base64) {
    try {
      var binary = atob(base64);
      var bytes = new Uint8Array(binary.length);
      for (var i = 0; i < binary.length; i++) {
        bytes[i] = binary.charCodeAt(i) & 0xff;
      }
      return bytes;
    } catch (e) {
      return null;
    }
  }

  function readFileWithNode(path, cb) {
    var nodeRequire = null;
    try {
      if (window.cep_node && window.cep_node.require) {
        nodeRequire = window.cep_node.require;
      } else if (window.require) {
        nodeRequire = window.require;
      }
    } catch (e) {
    }

    if (!nodeRequire) {
      cb(new Error('Node require is not available.'));
      return;
    }

    try {
      var fs = nodeRequire('fs');
      fs.readFile(path, function (err, data) {
        if (err) {
          cb(err);
          return;
        }
        var bytes = new Uint8Array(data);
        cb(null, bytes);
      });
    } catch (e2) {
      cb(e2);
    }
  }

  function readFileViaFetch(path, cb) {
    var url = 'file://' + encodeURI(path);
    fetch(url)
      .then(function (res) {
        if (!res.ok) {
          throw new Error('Fetch failed: ' + res.status);
        }
        return res.arrayBuffer();
      })
      .then(function (buf) {
        cb(null, new Uint8Array(buf));
      })
      .catch(function (err) {
        cb(err);
      });
  }

  function xhrRequest(opts, cb) {
    var xhr = new XMLHttpRequest();
    xhr.open(opts.method, opts.url, true);
    if (opts.headers) {
      Object.keys(opts.headers).forEach(function (key) {
        xhr.setRequestHeader(key, opts.headers[key]);
      });
    }
    xhr.responseType = opts.responseType || 'text';
    xhr.onload = function () {
      cb(null, xhr);
    };
    xhr.onerror = function () {
      cb(new Error('Network error'), xhr);
    };
    xhr.send(opts.body || null);
  }

  function normalizeProxyUrl(url) {
    if (!url) {
      return '';
    }
    return url.replace(/\/+$/, '');
  }

  function buildProxyHeaders(key, includeJson) {
    var headers = {};
    if (PROXY_KEY_HEADER) {
      var authVal = key;
      if (authVal) {
        headers[PROXY_KEY_HEADER] = authVal;
      }
    }
    if (includeJson) {
      headers['Content-Type'] = 'application/json';
    }
    return headers;
  }

  function uploadAudioToProxy(proxyKey, proxyUrl, mimeType, audioBytes, callback) {
    appendLog('Uploading audio to LiteLLM proxy...');

    var url = normalizeProxyUrl(proxyUrl) + PROXY_FILES_PATH + '?provider=' + encodeURIComponent(PROXY_FILES_PROVIDER);
    var form = new FormData();
    var blob = new Blob([audioBytes], { type: mimeType });
    form.append('file', blob, 'sequence_audio.wav');
    form.append('purpose', 'user_data');
    if (PROXY_FILES_TARGET_MODEL) {
      form.append('target_model_names', PROXY_FILES_TARGET_MODEL);
    }
    if (PROXY_FILES_TARGET_STORAGE) {
      form.append('target_storage', PROXY_FILES_TARGET_STORAGE);
    }
    form.append('custom_llm_provider', PROXY_FILES_CUSTOM_PROVIDER);
    form.append('litellm_metadata', PROXY_FILES_METADATA);

    xhrRequest({
      method: 'POST',
      url: url,
      headers: buildProxyHeaders(proxyKey, false),
      body: form
    }, function (err, xhr) {
      if (err) {
        callback(err);
        return;
      }
      if (xhr.status < 200 || xhr.status >= 300) {
        callback(new Error('Proxy upload failed: HTTP ' + xhr.status + ' ' + xhr.responseText));
        return;
      }
      var response;
      try {
        response = JSON.parse(xhr.responseText);
      } catch (e) {
        callback(new Error('Proxy upload response parse error.'));
        return;
      }
      var fileId = response.id || (response.file && response.file.id) || response.file_id;
      if (!fileId) {
        callback(new Error('Proxy upload response missing file id.'));
        return;
      }
      callback(null, fileId);
    });
  }

  function extractTextFromCompletion(response) {
    if (!response || !response.choices || !response.choices.length) {
      return '';
    }
    var message = response.choices[0].message || {};
    var content = message.content;
    if (typeof content === 'string') {
      return content;
    }
    if (Array.isArray(content)) {
      var parts = [];
      for (var i = 0; i < content.length; i++) {
        if (content[i] && content[i].text) {
          parts.push(content[i].text);
        }
      }
      return parts.join('\n');
    }
    return '';
  }

  function requestSrtFromProxy(proxyKey, proxyUrl, fileId, callback) {
    appendLog('Requesting subtitles via proxy...');

    var prompt = 'Transcribe the audio and return ONLY valid SRT text. ' +
      'Use 8-12 subtitle entries, accurate timestamps if possible. ' +
      'Format: HH:MM:SS,mmm --> HH:MM:SS,mmm. No markdown.';

    var body = {
      model: PROXY_MODEL_NAME,
      messages: [
        {
          role: 'user',
          content: [
            { type: 'text', text: prompt },
            { type: 'file', file: { file_id: fileId } }
          ]
        }
      ]
    };

    var url = normalizeProxyUrl(proxyUrl) + PROXY_CHAT_PATH;
    xhrRequest({
      method: 'POST',
      url: url,
      headers: buildProxyHeaders(proxyKey, true),
      body: JSON.stringify(body)
    }, function (err, xhr) {
      if (err) {
        callback(err);
        return;
      }
      if (xhr.status < 200 || xhr.status >= 300) {
        callback(new Error('Proxy request failed: HTTP ' + xhr.status + ' ' + xhr.responseText));
        return;
      }
      var response;
      try {
        response = JSON.parse(xhr.responseText);
      } catch (e) {
        callback(new Error('Proxy response parse error.'));
        return;
      }
      var text = extractTextFromCompletion(response);
      if (!text) {
        callback(new Error('Proxy returned no text.'));
        return;
      }
      callback(null, stripFences(text));
    });
  }

  function writeSrtAndImport(srtText, durationSeconds, onComplete) {
    if (!ensureOutputDir()) {
      appendLog('Could not create output folder: ' + OUTPUT_DIR, 'error');
      if (typeof onComplete === 'function') {
        onComplete(false);
      }
      return;
    }

    var srtPath = joinPath(OUTPUT_DIR, 'subtitles_' + makeTimestamp() + '.srt');
    var srtPathFs = toNativePath(srtPath);
    var normalized = normalizeSrtText(srtText, durationSeconds);
    var preview = normalized.replace(/\uFEFF/g, '').split(/\r\n|\n/).slice(0, 4).join(' | ');
    appendLog('SRT preview: ' + preview);
    var writeResult = window.cep.fs.writeFile(srtPathFs, normalized);

    if (writeResult.err !== 0) {
      appendLog('Failed to write SRT file: ' + srtPath, 'error');
      appendLog('CEP FS error code: ' + writeResult.err, 'error');
      if (typeof onComplete === 'function') {
        onComplete(false);
      }
      return;
    }

    appendLog('SRT written: ' + srtPath);
    runAction('Import Subtitles', 'qwint_importSubtitles("' + safePath(srtPath) + '")', function (result) {
      if (typeof onComplete === 'function') {
        onComplete(isOkResult(result));
      }
    });
  }

  function getSequenceDurationSeconds(cb) {
    cs.evalScript('qwint_getSequenceDurationSeconds()', function (res) {
      var seconds = 0;
      try {
        var parsed = JSON.parse(res);
        if (parsed && parsed.ok && parsed.details) {
          seconds = parseFloat(parsed.details);
        }
      } catch (e) {
      }
      cb(seconds);
    });
  }

  function generateSubtitlesProxy(onComplete) {
    var done = typeof onComplete === 'function' ? onComplete : null;
    var proxyKey = getProxyKey();
    if (!proxyKey) {
      appendLog('Missing proxy access key. Paste and save it first.', 'error');
      if (done) {
        done(false);
      }
      return;
    }
    var proxyUrl = getProxyUrl();
    if (!proxyUrl) {
      appendLog('Missing proxy base URL. Paste and save it first.', 'error');
      if (done) {
        done(false);
      }
      return;
    }

    var audioPath = lastAudioPath;
    if (!audioPath) {
      audioPath = findLatestWavPath();
    }
    if (!audioPath) {
      audioPath = joinPath(OUTPUT_DIR, 'sequence_audio.wav');
    }
    var audioPathFs = toNativePath(audioPath);
    var audioPathLog = normalizeFsPath(audioPathFs);
    appendLog('Using audio file: ' + audioPathLog);
    var stat = window.cep.fs.stat(audioPathFs);
    if (stat.err !== 0 || !stat.data) {
      var altPath = normalizeFsPath(audioPathFs);
      if (altPath && altPath !== audioPathFs) {
        var altStat = window.cep.fs.stat(altPath);
        if (altStat.err === 0 && altStat.data) {
          audioPathFs = altPath;
          audioPathLog = altPath;
          stat = altStat;
        }
      }
    }
    if (stat.err !== 0 || !stat.data) {
      appendLog('Audio file not found at ' + audioPathLog + ' (err ' + stat.err + ').', 'error');
      appendLog('Export step did not produce an audio file. Try again.', 'error');
      if (done) {
        done(false);
      }
      return;
    }

    var mimeType = 'audio/wav';

    function sendToProxy(bytes) {
      uploadAudioToProxy(proxyKey, proxyUrl, mimeType, bytes, function (err, fileId) {
        if (err) {
          appendLog(err.message, 'error');
          if (done) {
            done(false);
          }
          return;
        }
        appendLog('Upload complete. File ID: ' + fileId);
        requestSrtFromProxy(proxyKey, proxyUrl, fileId, function (err2, srtText) {
          if (err2) {
            appendLog(err2.message, 'error');
            if (done) {
              done(false);
            }
            return;
          }
          getSequenceDurationSeconds(function (seconds) {
            if (seconds) {
              appendLog('Sequence duration: ' + seconds.toFixed(2) + 's');
            }
            writeSrtAndImport(srtText, seconds, done);
          });
        });
      });
    }

    var bin = readFileBinary(audioPathFs);
    if (bin.ok) {
      appendLog('Audio bytes loaded via CEP FS (' + bin.bytes.length + ' bytes).');
      sendToProxy(bin.bytes);
      return;
    }

    appendLog('Binary read failed (code ' + bin.err + '). Trying Node fs...', 'error');
    readFileWithNode(audioPathFs, function (nodeErr, nodeBytes) {
      if (!nodeErr && nodeBytes) {
        appendLog('Audio bytes loaded via Node fs (' + nodeBytes.length + ' bytes).');
        sendToProxy(nodeBytes);
        return;
      }

      appendLog('Node fs read failed: ' + (nodeErr ? nodeErr.message : 'unknown'), 'error');
      appendLog('Trying file:// fetch...', 'error');
      readFileViaFetch(audioPathLog, function (fetchErr, bytes) {
        if (fetchErr) {
          appendLog('file:// fetch failed: ' + fetchErr.message, 'error');
          var base64 = readFileBase64(audioPathFs);
          if (!base64.ok) {
            appendLog('Base64 read failed (code ' + base64.err + ').', 'error');
            if (done) {
              done(false);
            }
            return;
          }
          var fallbackBytes = base64ToBytes(base64.base64);
          if (!fallbackBytes) {
            appendLog('Base64 decode failed.', 'error');
            if (done) {
              done(false);
            }
            return;
          }
          appendLog('Audio bytes loaded via base64 fallback (' + fallbackBytes.length + ' bytes).');
          sendToProxy(fallbackBytes);
          return;
        }

        appendLog('Audio bytes loaded via file:// fetch (' + bytes.length + ' bytes).');
        sendToProxy(bytes);
      });
    });
  }

  function wireEvents() {
    document.getElementById('btn-generate').addEventListener('click', function () {
      appendLog('Starting generate flow...');
      startGenerateFlow();
    });

    document.getElementById('btn-open').addEventListener('click', function () {
      runAction('Open Output Folder', 'qwint_openOutputFolder()');
    });

    document.getElementById('btn-save-key').addEventListener('click', function () {
      saveProxySettings();
    });

    document.getElementById('btn-reset-key').addEventListener('click', function () {
      resetProxyKey();
    });
  }

  document.addEventListener('DOMContentLoaded', function () {
    logEl = document.getElementById('log');
    proxyKeyInput = document.getElementById('api-key');
    proxyUrlInput = document.getElementById('proxy-url');
    generateBtn = document.getElementById('btn-generate');
    stepExportEl = document.getElementById('step-export');
    stepGenerateEl = document.getElementById('step-generate');
    stepDoneEl = document.getElementById('step-done');
    appendLog('Panel loaded.');
    appendLog('Output base: ' + pickBasePath());
    appendLog('Output dir: ' + OUTPUT_DIR);

    // Seed from config.json on first launch, then apply stored settings
    loadConfigFile(function () {
      loadSavedSettings();
    });

    loadJSX();
    wireSettingsToggle();
    wireEvents();
    resetProcessSteps();
  });
})();
