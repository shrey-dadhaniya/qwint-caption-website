# Qwint Subtitle Generator CEP — Project Summary

## Goal
Build a **CEP extension** for Adobe Premiere Pro (macOS + Windows) that:
- Exports audio from the active sequence to WAV.
- Sends audio to **Google Gemini API** to generate subtitles.
- Writes a valid SRT file and imports it into the active sequence as captions.
- Provides a polished UI with logs and minimal user friction.

## Current Extension Location
- **Workspace**: `/Users/shrey/Dev/clients/qwint/adobe-ext/QwintSubtitileCEP`
- **Installed (macOS)**: `/Library/Application Support/Adobe/CEP/extensions/QwintSubtitileCEP`
- **Installed (Windows)**: `C:\Program Files (x86)\Common Files\Adobe\CEP\extensions\QwintSubtitileCEP`

## Main Features (implemented)
1. **Export Audio**
   - Exports WAV with timestamped filename: `sequence_audio_YYYYMMDD_HHMMSS.wav`.
   - Uses preset bundled at `payloads/wav_48k_16bit.epr`.

2. **Generate Subtitles (Gemini)**
   - Uploads WAV to Gemini Files API (resumable upload).
   - Calls `generateContent` with the uploaded file.
   - Writes timestamped SRT: `subtitles_YYYYMMDD_HHMMSS.srt`.
   - Attempts to **normalize Gemini output** into valid SRT:
     - Supports proper SRT blocks.
     - Supports inline timestamp lines (timestamp + text on same line).
     - Falls back to evenly distributed captions if timestamps missing.

3. **Import SRT into Premiere**
   - `app.project.importFiles()` and `seq.createCaptionTrack()`.

4. **UI**
   - Matches provided PNG design (pure CSS, no Tailwind).
   - Responsive layout.
   - API key field with Save/Clear (stored in localStorage).

5. **Logging**
   - Detailed logs for export, upload, parsing, and import.

## Key Files
- UI HTML: `QwintSubtitileCEP/index.html`
- UI CSS: `QwintSubtitileCEP/css/style.css`
- Panel JS: `QwintSubtitileCEP/js/panel.js`
- ExtendScript: `QwintSubtitileCEP/QwintSubtitileCEP.jsx`
- Manifest: `QwintSubtitileCEP/CSXS/manifest.xml`

## Current Status
✅ CEP panel loads on Premiere Pro 2024+.
✅ Export audio works.
✅ Gemini API integration works (upload + response).
✅ SRT written with timestamped filenames.
✅ Import succeeds for some SRTs.

⚠️ **Ongoing Issue:**
Subtitles sometimes still appear as a single caption line or show timestamps inside text (unsynced).
Root cause: Gemini outputs **multiple timestamp lines without SRT blocks** or timestamps embedded in text lines. Parser fixes have been applied but need verification.

## Last Observed Bad Outputs
Examples in `/Users/shrey/Library/Application Support/subtitle-generator/`:
- `subtitles_20260207_193414.srt` → timestamps appear in text lines.
- `subtitles_20260209_120353.srt` → only one cue with multiple lines.

## Latest Parser Fix (panel.js)
Parser now:
- Detects true SRT blocks (single timestamp per block).
- Detects **inline timestamp lines** and splits into separate cues.
- Shifts cues so the earliest time starts at **00:00:00**.
- Scales cue timings if Gemini timings exceed sequence duration.

## Known Dependencies
- Gemini API key required in UI (stored locally).
- Node enabled in CEP (`--enable-nodejs`) to read WAV when CEP FS fails.
- WAV preset bundled in payloads.

## Commands to Update Installed Extension (macOS)
```bash
cp /Users/shrey/Dev/clients/qwint/adobe-ext/QwintSubtitileCEP/js/panel.js "/Library/Application Support/Adobe/CEP/extensions/QwintSubtitileCEP/js/panel.js"
cp /Users/shrey/Dev/clients/qwint/adobe-ext/QwintSubtitileCEP/QwintSubtitileCEP.jsx "/Library/Application Support/Adobe/CEP/extensions/QwintSubtitileCEP/QwintSubtitileCEP.jsx"
cp /Users/shrey/Dev/clients/qwint/adobe-ext/QwintSubtitileCEP/css/style.css "/Library/Application Support/Adobe/CEP/extensions/QwintSubtitileCEP/css/style.css"
cp /Users/shrey/Dev/clients/qwint/adobe-ext/QwintSubtitileCEP/CSXS/manifest.xml "/Library/Application Support/Adobe/CEP/extensions/QwintSubtitileCEP/CSXS/manifest.xml"
```
Restart Premiere after updates.

## Remaining Work
- Validate SRT parsing for all Gemini output variants.
- Ensure subtitles align with audio (sync) on timeline.
- Possibly tighten Gemini prompt for strict SRT format.
- Optional: add explicit SRT validator/debug preview in UI.

